# Create a new user

## First go to the following path

manage/users

![](../.gitbook/assets/screenshot-2020-04-18-at-14.14.55.png)

## Create a new user by pressing on "Add user"

Fill out the form and press "create new user" 

![](../.gitbook/assets/screenshot-2020-04-18-at-14.16.54.png)



