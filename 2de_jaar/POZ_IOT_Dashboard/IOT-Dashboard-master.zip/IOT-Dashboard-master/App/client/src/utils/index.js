/* eslint-disable */
export const generateSnackbar = (snackbar, color, text) => {
  snackbar.color = color;
  snackbar.text = text;
  snackbar.show = true;
};
