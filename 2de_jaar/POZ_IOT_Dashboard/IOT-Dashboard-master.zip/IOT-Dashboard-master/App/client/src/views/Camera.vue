<template>
  <iframe
    width="1280"
    height="720"
    src="http://192.168.0.17:8080"
    frameborder="0"
    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
    allowfullscreen="allowfullscreen"
  ></iframe>
</template>
