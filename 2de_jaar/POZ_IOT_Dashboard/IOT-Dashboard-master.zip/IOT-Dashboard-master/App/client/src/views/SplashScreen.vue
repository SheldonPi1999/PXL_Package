<template>
  <div style="position:absolute; width: 100%; height:100%; top:0; left:0; z-index:10000; background-color:white">
    <div style="margin-left: auto; margin-right: auto">
      <div id="loader-wrapper">
        <div id="loader"></div>
        <div class="loader-section section-left"></div>
        <div class="loader-section section-right"></div>
      </div>
    </div>
  </div>
</template>
