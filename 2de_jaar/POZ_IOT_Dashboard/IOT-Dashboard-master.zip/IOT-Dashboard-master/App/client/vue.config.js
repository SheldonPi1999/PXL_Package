module.exports = {
  transpileDependencies: ['vuetify', 'feathers-vuex'],
};
