module.exports = {
  activities: 'activities',
  notifications: 'notifications',
  users: 'users',
};
