const { Service } = require('feathers-mongoose');

exports.Activities = class Activities extends Service {};
