const { Service } = require('feathers-mongoose');
exports.Notifications = class Notifications extends Service {};
