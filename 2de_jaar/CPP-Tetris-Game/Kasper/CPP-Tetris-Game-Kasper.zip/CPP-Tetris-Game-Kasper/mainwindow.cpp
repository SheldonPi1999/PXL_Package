#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "qmessagebox.h"

#include "gamesetup.h"
#include "w_leaderboard.h"
#include "w_settings.h"

#include <QCloseEvent>
#include <QtWidgets/QApplication>

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
	ui->setupUi(this);
}

MainWindow::~MainWindow()
{
	delete ui;
}

void MainWindow::on_btn_newgame_clicked()
{
    hide();
    gamesetup = new class gamesetup(this);
    gamesetup->show();
}

void MainWindow::on_btn_continue_clicked()
{
    QApplication::quit();
}

void MainWindow::on_btn_leaderboard_clicked()
{
    hide();
    w_leaderboard = new class w_leaderboard(this);
    w_leaderboard->show();
}

void MainWindow::on_btn_settings_clicked()
{
    hide();
    w_settings = new class w_settings(this);
    w_settings->show();
}

void MainWindow::on_btn_exit_clicked()
{
    QApplication::quit();
}

void MainWindow::closeEvent (QCloseEvent *event)
{
    QMessageBox::StandardButton resBtn = QMessageBox::question( this, "Tetris",
                                                                tr("Are you sure?\n"),
                                                                QMessageBox::No | QMessageBox::Yes,
                                                                QMessageBox::Yes);
    if (resBtn != QMessageBox::Yes)
    {
        event->ignore();
    }
    else {
        event->accept();
    }
}
