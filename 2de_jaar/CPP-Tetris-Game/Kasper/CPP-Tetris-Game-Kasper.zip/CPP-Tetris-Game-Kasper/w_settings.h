#ifndef W_SETTINGS_H
#define W_SETTINGS_H

#include <QDialog>

namespace Ui {
class w_settings;
}

class w_settings : public QDialog
{
    Q_OBJECT

public:
    explicit w_settings(QWidget *parent = nullptr);
    ~w_settings();

protected:
    void closeEvent(QCloseEvent *event) override;

private:
    Ui::w_settings *ui;

private slots:
    void on_btn_quit_clicked();
};

#endif // W_SETTINGS_H
