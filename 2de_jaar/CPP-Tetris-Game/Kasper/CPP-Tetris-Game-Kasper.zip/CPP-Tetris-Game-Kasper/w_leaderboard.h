#ifndef W_LEADERBOARD_H
#define W_LEADERBOARD_H

#include <QDialog>

namespace Ui {
class w_leaderboard;
}

class w_leaderboard : public QDialog
{
    Q_OBJECT

public:
    explicit w_leaderboard(QWidget *parent = nullptr);
    ~w_leaderboard();

protected:
    void closeEvent(QCloseEvent *event) override;

private:
    Ui::w_leaderboard *ui;

private slots:
    void on_btn_quit_clicked();
};

#endif // W_LEADERBOARD_H
