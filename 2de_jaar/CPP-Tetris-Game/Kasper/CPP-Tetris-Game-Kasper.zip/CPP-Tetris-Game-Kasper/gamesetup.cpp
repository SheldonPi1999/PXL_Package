#include "gamesetup.h"
#include "ui_gamesetup.h"
#include "QMessageBox"
#include "mainwindow.h"

#include <QCloseEvent>

gamesetup::gamesetup(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::gamesetup)
{
    ui->setupUi(this);
}

gamesetup::~gamesetup()
{
    delete ui;
}


void gamesetup::on_btn_quit_clicked()
{
    this->hide();
    // Show the MainWindow (i.e. the parent window)
    QWidget *parent = this->parentWidget();
    parent->show();
}

void gamesetup::closeEvent (QCloseEvent *event)
{
    QMessageBox::StandardButton resBtn = QMessageBox::question( this, "Tetris",
                                                                tr("Back to main?\n"),
                                                                QMessageBox::No | QMessageBox::Yes,
                                                                QMessageBox::Yes);
    if (resBtn != QMessageBox::Yes)
    {
        event->ignore();
    }

    else {
        this->hide();
        // Show the MainWindow (i.e. the parent window)
        QWidget *parent = this->parentWidget();
        parent->show();
    }
}


