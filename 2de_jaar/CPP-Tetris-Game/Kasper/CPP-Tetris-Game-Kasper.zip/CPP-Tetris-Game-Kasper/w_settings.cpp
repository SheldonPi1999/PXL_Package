#include "w_settings.h"
#include "QMessageBox"
#include "ui_w_settings.h"

#include <QCloseEvent>

w_settings::w_settings(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::w_settings)
{
    ui->setupUi(this);
}

w_settings::~w_settings()
{
    delete ui;
}

void w_settings::on_btn_quit_clicked()
{
    this->hide();
    // Show the MainWindow (i.e. the parent window)
    QWidget *parent = this->parentWidget();
    parent->show();
}

void w_settings::closeEvent (QCloseEvent *event)
{
    QMessageBox::StandardButton resBtn = QMessageBox::question( this, "Tetris",
                                                                tr("Back to main?\n"),
                                                                QMessageBox::No | QMessageBox::Yes,
                                                                QMessageBox::Yes);
    if (resBtn != QMessageBox::Yes)
    {
        event->ignore();
    }

    else {
        this->hide();
        // Show the MainWindow (i.e. the parent window)
        QWidget *parent = this->parentWidget();
        parent->show();
    }
}
