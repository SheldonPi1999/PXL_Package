<<<<<<< HEAD:tetris/main.cpp
#include "tetris.h"
#include "menu.h"
=======
>>>>>>> 9da300e3df3d0647333aebfb3eaeb10aee868975:Tetris/main.cpp
#include <QtWidgets/QApplication>
#include "Tetris.h"


int main(int argc, char* argv[])
{
	QApplication a(argc, argv);
<<<<<<< HEAD:tetris/main.cpp
	tetris w;
	tetris mainWindow;
	//mainWindow.showMaximized();
=======
	MainWindow w;
>>>>>>> 9da300e3df3d0647333aebfb3eaeb10aee868975:Tetris/main.cpp
	w.show();
	return a.exec();
}

