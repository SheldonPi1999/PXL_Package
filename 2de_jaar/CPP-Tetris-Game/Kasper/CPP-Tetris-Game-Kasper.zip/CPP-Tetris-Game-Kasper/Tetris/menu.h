#ifndef MENU_H
#define MENU_H

class Menu
{
	public:
		int newGame(void);
		int continueGame(void);
		int quit(void);
		int sound(void);
		int leaderboard(void);
		int settings(void);
};

#endif // Menu_H