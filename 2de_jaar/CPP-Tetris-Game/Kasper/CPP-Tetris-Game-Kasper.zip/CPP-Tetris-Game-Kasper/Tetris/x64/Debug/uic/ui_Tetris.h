/********************************************************************************
** Form generated from reading UI file 'Tetris.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TETRIS_H
#define UI_TETRIS_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *btn_newgame;
    QPushButton *btn_continue;
    QPushButton *btn_leaderboard;
    QPushButton *btn_settings;
    QPushButton *btn_quit;
    QRadioButton *btn_sound;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QPlainTextEdit *plainTextEdit;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(799, 600);
        MainWindow->setAutoFillBackground(false);
        MainWindow->setStyleSheet(QString::fromUtf8("QMainWindow {\n"
"	background-image: url(:/Tetris/background.png)\n"
"}"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8("background-image: url(\"\\Resources\\background.png\")"));
        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(250, 170, 281, 291));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        btn_newgame = new QPushButton(verticalLayoutWidget);
        btn_newgame->setObjectName(QString::fromUtf8("btn_newgame"));

        verticalLayout->addWidget(btn_newgame);

        btn_continue = new QPushButton(verticalLayoutWidget);
        btn_continue->setObjectName(QString::fromUtf8("btn_continue"));

        verticalLayout->addWidget(btn_continue);

        btn_leaderboard = new QPushButton(verticalLayoutWidget);
        btn_leaderboard->setObjectName(QString::fromUtf8("btn_leaderboard"));

        verticalLayout->addWidget(btn_leaderboard);

        btn_settings = new QPushButton(verticalLayoutWidget);
        btn_settings->setObjectName(QString::fromUtf8("btn_settings"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("Tetris.ico"), QSize(), QIcon::Normal, QIcon::Off);
        btn_settings->setIcon(icon);

        verticalLayout->addWidget(btn_settings);

        btn_quit = new QPushButton(verticalLayoutWidget);
        btn_quit->setObjectName(QString::fromUtf8("btn_quit"));

        verticalLayout->addWidget(btn_quit);

        btn_sound = new QRadioButton(centralwidget);
        btn_sound->setObjectName(QString::fromUtf8("btn_sound"));
        btn_sound->setGeometry(QRect(690, 20, 86, 17));
        verticalLayoutWidget_2 = new QWidget(centralwidget);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(0, 500, 801, 89));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        plainTextEdit = new QPlainTextEdit(verticalLayoutWidget_2);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));

        verticalLayout_2->addWidget(plainTextEdit);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 799, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        btn_newgame->setText(QApplication::translate("MainWindow", "New Game", nullptr));
        btn_continue->setText(QApplication::translate("MainWindow", "Continue", nullptr));
        btn_leaderboard->setText(QApplication::translate("MainWindow", "Leaderboard", nullptr));
        btn_settings->setText(QApplication::translate("MainWindow", "Settings", nullptr));
        btn_quit->setText(QApplication::translate("MainWindow", "Quit", nullptr));
        btn_sound->setText(QApplication::translate("MainWindow", "Sound", nullptr));
        plainTextEdit->setPlainText(QApplication::translate("MainWindow", "Copyright 2019\n"
"", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TETRIS_H
