#include "Tetris.h"
#include "ui_Tetris.h"
#include "qmessagebox.h"
#include "resource.h"

MainWindow::MainWindow(QWidget* parent)
	: QMainWindow(parent)
	, ui(new Ui::MainWindow)
{
	ui->setupUi(this);

}

MainWindow::~MainWindow()
{
	delete ui;
}


void MainWindow::on_btn_newgame_clicked()
{
	QMessageBox::information(this, "Hello patel ", "button clicked");
}
