#include <iostream>
#include "menu.h"
#include "mainwindow.h"

int Menu::newGame(void)
{
	return 0;
}

int Menu::continueGame(void)
{
	return 0;
}

int Menu::quit(void)
{
	return 0;
}

int Menu::sound(void)
{
	return 0;
}

int Menu::leaderboard(void)
{
	return 0;
}

int Menu::settings(void)
{
	return 0;
}


