#ifndef GAMESETUP_H
#define GAMESETUP_H

#include <QDialog>

namespace Ui {
class gamesetup;
}

class gamesetup : public QDialog
{
    Q_OBJECT

public:
    explicit gamesetup(QWidget *parent = nullptr);
    ~gamesetup();

private slots:
    void on_btn_quit_clicked();


protected:
    void closeEvent(QCloseEvent *event) override;

private:
    Ui::gamesetup *ui;
};

#endif // GAMESETUP_H
