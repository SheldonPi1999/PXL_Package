#include "w_leaderboard.h"
#include "QMessageBox"
#include "ui_w_leaderboard.h"

#include <QCloseEvent>

w_leaderboard::w_leaderboard(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::w_leaderboard)
{
    ui->setupUi(this);
}

w_leaderboard::~w_leaderboard()
{
    delete ui;
}

void w_leaderboard::on_btn_quit_clicked()
{
    this->hide();
    // Show the MainWindow (i.e. the parent window)
    QWidget *parent = this->parentWidget();
    parent->show();
}

void w_leaderboard::closeEvent (QCloseEvent *event)
{
    QMessageBox::StandardButton resBtn = QMessageBox::question( this, "Tetris",
                                                                tr("Back to main?\n"),
                                                                QMessageBox::No | QMessageBox::Yes,
                                                                QMessageBox::Yes);
    if (resBtn != QMessageBox::Yes)
    {
        event->ignore();
    }

    else {
        this->hide();
        // Show the MainWindow (i.e. the parent window)
        QWidget *parent = this->parentWidget();
        parent->show();
    }
}
