/*
 * This file is part of Jens Vanhulst & Kasper toetenel.
 *
 * Developed for the C++ Object-Oriented-Programming Project.
 * This product includes software developed by the LSST Project
 * (https://www.lsst.org).
 * See the COPYRIGHT file at the top-level directory of this distribution
 * for details of code ownership.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "menu.h"
#include "ui_menu.h"
#include "stackcontroller.h"
#include "gamesetup.h"
#include <QStackedWidget>
#include "gamewindow.h"

Menu::Menu(QWidget *parent) : QWidget(parent), ui(new Ui::Menu)
{
    //Setup UI
    ui->setupUi(this);

    //Connect buttons
    QObject::connect( ui->btn_newgame, &QPushButton::clicked, this, &Menu::btn_new_game_clicked );
    QObject::connect( ui->btn_continue, &QPushButton::clicked, this, &Menu::btn_continue_clicked );
    QObject::connect( ui->btn_leaderboard, &QPushButton::clicked, this, &Menu::btn_leaderboard_clicked );
    QObject::connect( ui->btn_settings, &QPushButton::clicked, this, &Menu::btn_settings_clicked );
    QObject::connect( ui->btn_exit, &QPushButton::clicked, this, &Menu::btn_exit_clicked );
    QObject::connect( ui->btn_sound, &QPushButton::clicked, this, &Menu::btn_sound_clicked );

    //Make button for the sound checkable 
    ui->btn_sound->setCheckable(true);
}

Menu::~Menu()
{
    delete ui;
}

/**
    Handles the sound button click

    @param none
    @return t = bool - state of the button (0,1)
*/
bool Menu::on_btn_sound_clicked()
{
    bool t = ui->btn_sound->isChecked();
    return t;
}
