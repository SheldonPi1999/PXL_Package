/*
 * This file is part of Jens Vanhulst & Kasper toetenel.
 *
 * Developed for the C++ Object-Oriented-Programming Project.
 * This product includes software developed by the LSST Project
 * (https://www.lsst.org).
 * See the COPYRIGHT file at the top-level directory of this distribution
 * for details of code ownership.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "settings.h"
#include "ui_settings.h"

Settings::Settings(QWidget *parent) : QWidget(parent), ui(new Ui::Settings)
{
    //Setup UI
    ui->setupUi(this);

    //connect buttons
    QObject::connect(ui->btn_back, &QPushButton::clicked, this, &Settings::btn_back_clicked );
    QObject::connect(ui->btn_fullscreen, &QPushButton::clicked, this, &Settings::btn_fullscreen_clicked );
    QObject::connect(ui->btn_language, &QPushButton::clicked, this, &Settings::btn_language_clicked );
    QObject::connect(ui->btn_rules, &QPushButton::clicked, this, &Settings::btn_rules_clicked );
    QObject::connect(ui->btn_support, &QPushButton::clicked, this, &Settings::btn_support_clicked );
    QObject::connect(ui->btn_theme, &QPushButton::clicked, this, &Settings::btn_theme_clicked );

    //make sound buttons checkable
    ui->btn_sound->setCheckable(true);
    ui->btn_fullscreen->setCheckable(true);
}

Settings::~Settings()
{
    delete ui;
}


/**
    Handles the state of the buttons

    @param none 
    @return x - bool value of the button
*/
bool Settings::on_btn_fullscreen_clicked()
{
    bool x = ui->btn_fullscreen->isChecked();
    return x;
}

/**
    Encodes a single digit of a POSTNET "A" bar code.

    @param none
    @return t - bool value of the button
*/
bool Settings::on_btn_sound_clicked()
{
    bool t = ui->btn_sound->isChecked();
    return t;
}
