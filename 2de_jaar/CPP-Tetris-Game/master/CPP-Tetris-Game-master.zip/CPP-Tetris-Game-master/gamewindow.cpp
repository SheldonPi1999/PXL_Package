/*
 * This file is part of {{ cookiecutter.package_name }}.
 *
 * Developed for the LSST Data Management System.
 * This product includes software developed by the LSST Project
 * (https://www.lsst.org).
 * See the COPYRIGHT file at the top-level directory of this distribution
 * for details of code ownership.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


#include <QtWidgets>
#include "gamegrid.h"
#include "gamewindow.h"
#include "stackcontroller.h"
#include "gamesetup.h"

GameWindow::GameWindow(QWidget *parent)
{
    //Create 2 grids
    grid     = new GameGrid;
    maingrid = new GameGrid;

    //TextLabel Place Holder -- Next;
    nextBlockLabel = new QLabel;
    nextBlockLabel->setFrameStyle(QFrame::Box | QFrame::Raised);
    nextBlockLabel->setAlignment(Qt::AlignCenter);
    nextBlockLabel->setStyleSheet("background-color: transparent;");

    //Score-LCD;
    scoreLcd = new QLCDNumber(5);
    scoreLcd->setSegmentStyle(QLCDNumber::Filled);
    scoreLcd->setStyleSheet("background-color: transparent;");

    //Start-Button;
    startButton = new QPushButton();
    startButton->setStyleSheet("background-color: transparent;");

    //Quit-Button;
    quitButton = new QPushButton();
    quitButton->setStyleSheet("background-color: transparent; position: fixed; min-width: 150px; min-height: 60px;");

    //Pause-Button;
    pauseButton = new QPushButton();
    pauseButton->setStyleSheet("background-color: transparent;");

    //Connects the button with the appropriate action;
    QObject::connect(startButton, &QPushButton::clicked, grid, &GameGrid::start);
    //QObject::connect( quitButton, &QPushButton::clicked, this, &GameWindow::btn_exit_clicked );
    QObject::connect( quitButton, &QPushButton::clicked, grid, &GameGrid::end );

    QObject::connect(grid, &GameGrid::scoreChanged, scoreLcd, QOverload<int>::of(&QLCDNumber::display));

    //Creater Layout;
    QGridLayout *layout = new QGridLayout;

    //Adds all the components to the layout;
    //addwidget(int r, int c, int rowspan, int columnspan);
    layout->addWidget(maingrid, 0, 0, 6, 3);
    layout->addWidget(grid, 0, 1, 6, 1);

    maingrid->setStyleSheet("border-image: url(:/backgrounds/assets/backgrounds/bg_2.jpg)");
    layout->addWidget(createLabel(tr("NEXT")), 0, 0);
    layout->addWidget(nextBlockLabel, 0, 0);
    layout->addWidget(createLabel(tr("SCORE")), 0, 2);
    layout->addWidget(scoreLcd, 0, 2);

    layout->addWidget(startButton, 3, 2);
    startButton->setStyleSheet("border-image: url(:/buttons/assets/buttons/play.png); height: 100px !important;");
    layout->addWidget(quitButton, 4, 2);
    quitButton->setStyleSheet("border-image: url(:/buttons/assets/buttons/exit.png); height: 100px !important;");
    layout->addWidget(pauseButton, 5, 2);
    pauseButton->setStyleSheet("border-image: url(:/buttons/assets/buttons/pause.png); height: 100px !important;");
    setLayout(layout);
}


/**
    Create lables for the ui 

    @param String text - Text for the label
    @return label - Returns the label
*/
QLabel *GameWindow::createLabel(const QString &text)
{
    QLabel *label = new QLabel(text);
    label->setAlignment(Qt::AlignHCenter | Qt::AlignBottom);
    return label;
}
