/*
 * This file is part of Jens Vanhulst & Kasper toetenel.
 *
 * Developed for the C++ Object-Oriented-Programming Project.
 * This product includes software developed by the LSST Project
 * (https://www.lsst.org).
 * See the COPYRIGHT file at the top-level directory of this distribution
 * for details of code ownership.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "stackcontroller.h"
#include "menu.h"
#include "gamesetup.h"
#include "leaderboard.h"
#include "settings.h"
#include "language.h"
#include "support.h"
#include "theme.h"
#include "rules.h"
#include "gamewindow.h"
#include "main.cpp"
#include <QStackedWidget>
#include <QDebug>

#include <QtGlobal>
#include "player.h"

#include <string>

using namespace std;

StackController::StackController(QWidget *parent) : QMainWindow(parent)
{
    menu = new Menu(this);
    gamesetup = new Gamesetup(this);
    leaderboard = new Leaderboard(this);
    settings = new Settings(this);
    language = new Language(this);
    support = new Support(this);
    theme = new Theme(this);
    rules = new Rules(this);
    gamewindow = new GameWindow(this);

    mediaplayer = new QMediaPlayer(this);

    stackedWidget = new QStackedWidget();

    //Add all widgets to the stack
    stackedWidget->addWidget(menu);
    stackedWidget->addWidget(gamesetup);
    stackedWidget->addWidget(leaderboard);
    stackedWidget->addWidget(settings);
    stackedWidget->addWidget(language);
    stackedWidget->addWidget(support);
    stackedWidget->addWidget(theme);
    stackedWidget->addWidget(rules);
    stackedWidget->addWidget(gamewindow);

    //Set default view when the program starts up
    stackedWidget->setCurrentWidget(menu);
    stackedWidget->show();

    //Connects the menu buttons to the stack controller functions.
    QObject::connect( menu, &Menu::btn_new_game_clicked, this, &StackController::showNewGame );
    QObject::connect( menu, &Menu::btn_continue_clicked, this, &StackController::showContinue );
    QObject::connect( menu, &Menu::btn_leaderboard_clicked, this, &StackController::showLeaderboard );
    QObject::connect( menu, &Menu::btn_settings_clicked, this, &StackController::showSettings );
    QObject::connect( menu, &Menu::btn_exit_clicked, this, &StackController::exit );
    QObject::connect( menu, &Menu::btn_sound_clicked, this, &StackController::toggleSound_menu );

    //Connects the gamesetup buttons to the stack controller functions.
    QObject::connect( gamesetup, &Gamesetup::btn_startgame_clicked, this, &StackController::showContinue );
    QObject::connect( gamesetup, &Gamesetup::btn_quit_clicked, this, &StackController::back_to_menu );
    
    //Connects the settings buttons to the stack controller functions.
    QObject::connect( settings, &Settings::btn_back_clicked, this, &StackController::back_to_menu );
    QObject::connect( settings, &Settings::btn_fullscreen_clicked, this, &StackController::setFullscreen );
    QObject::connect( settings, &Settings::btn_language_clicked, this, &StackController::showLanguage );
    QObject::connect( settings, &Settings::btn_rules_clicked, this, &StackController::showRules );
    QObject::connect( settings, &Settings::btn_support_clicked, this, &StackController::showSupport);
    QObject::connect( settings, &Settings::btn_theme_clicked, this, &StackController::showTheme );
    QObject::connect( settings, &Settings::btn_sound_clicked, this, &StackController::toggleSound_settings );

    //Connects the rules back button to the stack controller function.
    QObject::connect( rules, &Rules::btn_back_clicked, this, &StackController::showSettings );

    //Connects the theme back button to the stack controller function.
    QObject::connect( theme, &Theme::btn_back_clicked, this, &StackController::showSettings );

    //Connects the support back button to the stack controller function.
    QObject::connect( support, &Support::btn_back_clicked, this, &StackController::showSettings );

    //Connects the leaderboard back button to the stack controller function.
    QObject::connect( leaderboard, &Leaderboard::btn_back_clicked, this, &StackController::showSettings );

    //Connects the language back button to the stack controller function.
    QObject::connect( language, &Language::btn_back_clicked, this, &StackController::showSettings );

    //Connects the gamewindow exit button to the stack controller function.
    QObject::connect( gamewindow, &GameWindow::btn_exit_clicked, this, &StackController::back_to_menu );

    // Creates a QT MediaPlaylist
    playlist = new QMediaPlaylist();
    playlist->addMedia(QUrl("qrc:/sounds/assets/sounds/1.wav"));
    playlist->setPlaybackMode(QMediaPlaylist::Loop);

    // Playes the QT Playlist
    mediaplayer->setPlaylist(playlist);
    mediaplayer->setVolume(0);
    mediaplayer->play();
}

StackController::~StackController()
{

}

/**
    Shows the gamesetup widget from the stack.
    @param none
    @return none
**/

void StackController::showNewGame()
{
    stackedWidget->setCurrentWidget(gamesetup);
}

/**
    Shows the gamewindow widget from the stack.
    @param none
    @return none
**/

void StackController::showContinue()
{
    stackedWidget->setCurrentWidget(gamewindow);
}

/**
    Shows the leaderboard widget from the stack.
    @param none
    @return none
**/

void StackController::showLeaderboard()
{
    stackedWidget->setCurrentWidget(leaderboard);
}

/**
    Shows the settings widget from the stack.
    @param none
    @return none
**/

void StackController::showSettings()
{
    stackedWidget->setCurrentWidget(settings);
}

/**
    Shows the language widget from the stack.
    @param none
    @return none
**/

void StackController::showLanguage()
{
    stackedWidget->setCurrentWidget(language);
}

/**
    Shows the rules widget from the stack.
    @param none
    @return none
**/

void StackController::showRules()
{
    stackedWidget->setCurrentWidget(rules);
}

/**
    Shows the support widget from the stack.
    @param none
    @return none
**/

void StackController::showSupport()
{
    stackedWidget->setCurrentWidget(support);
}

/**
    Shows the theme widget from the stack.
    @param none
    @return none
**/

void StackController::showTheme()
{
    stackedWidget->setCurrentWidget(theme);
}

/**
    Shows the menu widget from the stack.
    @param none
    @return none
**/

void StackController::back_to_menu()
{
   stackedWidget->setCurrentWidget(menu);
}

/**
    Exits the application.
    @param none
    @return none
**/

void StackController::exit() {
    QApplication::quit();
}

/**
    Toggles the application in Windowed-/Fullscreen-Mode
    @param none
    @return none
**/

void StackController::setFullscreen()
{

    bool x = settings->on_btn_fullscreen_clicked();
    if(x == true)
    {
        stackedWidget->showFullScreen();
    }

    else
        this->setWindowState(Qt::WindowMaximized);
}

/**
    Toggles the menu sound of the application ON or OFF
    @param none
    @return none
**/

void StackController::toggleSound_menu()
{ 
    bool t = menu->on_btn_sound_clicked();
    if(t == true)
    {
        mediaplayer->stop();
    }

    else
        mediaplayer->play();
}


/**
    Toggles the settings sound of the application ON or OFF
    @param none
    @return none
**/

void StackController::toggleSound_settings()
{
    bool t = settings->on_btn_sound_clicked();
    if(t == true)
    {
        mediaplayer->stop();
    }

    else
        mediaplayer->play();
}
