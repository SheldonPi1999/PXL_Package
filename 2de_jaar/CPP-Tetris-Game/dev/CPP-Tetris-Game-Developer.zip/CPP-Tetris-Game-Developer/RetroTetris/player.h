/*
 * This file is part of Jens Vanhulst & Kasper toetenel.
 *
 * Developed for the C++ Object-Oriented-Programming Project.
 * This product includes software developed by the LSST Project
 * (https://www.lsst.org).
 * See the COPYRIGHT file at the top-level directory of this distribution
 * for details of code ownership.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef PLAYER_H
#define PLAYER_H
#include <string>
#include <iostream>

using namespace std;

class player
{

private:
    string playerName;
    int playerScore{0};
    int playerHighscore{0};

public:
    //Constructor
    player(string pName, int pScore=0, int pHighscore=0) {
        this->setPlayerName(pName);
        this->setPlayerScore(pScore);
        this->setPlayerHighscore(pHighscore);
    }


    //Setters
    void setPlayerName ( string pName ) { this->playerName = pName; }
    void setPlayerScore( int pScore ) { this->playerScore = pScore;}
    void setPlayerHighscore ( int pHighscore ) { this->playerHighscore = pHighscore; }

    //getters
    string getPlayerName() const { return this->playerName; }
    int getPlayerScore() const { return this->playerScore; }
    int getPlayerHighscore() const { return this->playerHighscore; }

    // member functions
    void writeToCSV(string path , string d1, int d2, int d3 );
    void readFromCSV(string path);

};
#endif // PLAYER_H
