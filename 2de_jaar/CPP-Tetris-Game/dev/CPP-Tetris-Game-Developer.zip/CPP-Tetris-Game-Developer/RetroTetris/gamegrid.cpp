/*
 * This file is part of Jens Vanhulst & Kasper toetenel.
 *
 * Developed for the C++ Object-Oriented-Programming Project.
 * This product includes software developed by the LSST Project
 * (https://www.lsst.org).
 * See the COPYRIGHT file at the top-level directory of this distribution
 * for details of code ownership.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include <QtWidgets>
#include <QDebug>
#include "gamegrid.h"

#define __DEBUG__

GameGrid::GameGrid(QWidget *parent): QFrame(parent)
 {
    // Boolean to check if the game isn't started yet
    isStarted = true;
    //Players score;
    score = 0;

    // Sets style to panel;
    setFrameStyle(QFrame::Panel);
    setStyleSheet("background-color: transparent");
    // StrongFocus gets keyboard- or click input;
    setFocusPolicy(Qt::StrongFocus);
}

/**
    Starts the game creates a new player and drops a new piece
    @param none
    @return none
**/

void GameGrid::start()
{ 
    // Checks that the game is started;
    isStarted = true;
    //Create new player object & values are automatically 0
    pl = new player("Jens");

    // Calls the newPiece function;
    newPiece();
}

/**
    Ends the program and writes the player's value to a csv file
    @param none
    @return none
**/

void GameGrid::end() {
    //Set the players score to the current ingame score
    pl->setPlayerHighscore(score);
    //write to csv
    pl->writeToCSV("/Users/jens/Desktop/data.csv","jens",score, pl->getPlayerHighscore() );
    //exit the application
    qApp->exit();
}

/**
    Function to drop a new piece
    @param none
    @return none
**/

void GameGrid::newPiece()
{
    #ifdef __DEBUG__
        qDebug() << "New piece dropped";
    #endif

    // Make a new current block;
    curPiece[t] = nextPiece;
    
    // Set a random shape for the block
    nextPiece.setRandomShape();

    // X-position of the incoming block;
    startX = BoardWidth / 2;

    // Y-position of the incoming block;
    startY = BoardHeight - 2;
    
    update();
}


/**
    Draws the outline of the tetris block
    @param *event
    @return none
**/

void GameGrid::paintEvent(QPaintEvent *event)
{
    // Makes the playgrid;
    QFrame::paintEvent(event);

    QPainter painter(this);
    QRect rect = contentsRect();

    // Top of the board = height of the grid - (amount of blocks * height of each block)
    int boardTop = rect.bottom() - BoardHeight * squareHeight();
    
    #ifdef __DEBUG__
        qDebug() << "BoardHeight: "  << BoardHeight;
        qDebug() << "SquareHeight: " << squareHeight();
    #endif

    // If there is a shape it will pass trough the the data of each of the four squares and draw an imaginable rectangle of them.
    int kj = 0;

    while(kj<=t)
    {
        if (curPiece[0].shape() != NoShape)
        {
            #ifdef __DEBUG__
                qDebug() << "In ifblock";
            #endif
            
             // Draws the actual outline.
            for (int i = 0; i < 4; ++i)
            {
                int x = startX + curPiece[0].x(i);
                int y = startY - curPiece[0].y(i);
                drawSquare(painter, rect.left() + (x * squareWidth()), boardTop + (BoardHeight - y - 1) * squareHeight());
            }
        }
        kj++;
    }
}

/**
    Gives the blocks/squares a color. Makes the imagine shapes visual
    @param &painter
    @param int x - Top left x-position of the tetris block
    @param int y - Top left y-position of the tetris block
    @return none
**/

void GameGrid::drawSquare(QPainter &painter, int x, int y)
{
    static const QRgb colorTable[6] = {0xAD57FF, 0xFF7600, 0x008FFF, 0x49C346, 0xC7C43A, 0x8F59BA};

    QColor color = colorTable[QRandomGenerator::global()->bounded(6)];
    painter.fillRect(x + 1, y + 1, squareWidth() - 2, squareHeight() - 2, color);

    if(startY == 1)
    {
        #ifdef __DEBUG__
            qDebug() << "StartY == 1";
        #endif

        t++;
        newPiece();
    }
}


/**
    Handles the user input.
    @param *event : the QT key event for the corresponding key
    @return none
**/
void GameGrid::keyPressEvent(QKeyEvent *event)
{
    switch (event->key())
    {
        case Qt::Key_Left:
        {
            #ifdef __DEBUG__
                qDebug() << "lefter Clicked";
            #endif
            
            tryMove(curPiece[t], startX - 1, startY);
            break;
        }
        case Qt::Key_Right:
        {
            #ifdef __DEBUG__
                qDebug() << "righter Clicked";
            #endif
            
            tryMove(curPiece[t], startX + 1, startY);
            break;
        }
        case Qt::Key_Down:
        {
            
            score += 10;
            pl->setPlayerScore(score);
            emit scoreChanged(score);
            tryMove(curPiece[t], startX, startY - 1);
            
            #ifdef __DEBUG__
                qDebug() << score << endl;
                qDebug() << "downy Clicked";
            #endif
            break;
        }
        
        // Future-Update: Rotation
        case Qt::Key_Up:
        {
            #ifdef __DEBUG__
                qDebug() << "uppy Clicked";
            #endif
            
            tryMove(curPiece[t], startX, startY + 1);
            break;
        }

        case Qt::Key_Space:
        {
            #ifdef __DEBUG__
                qDebug() << "Spacebar clicked";
                qDebug() << BoardHeight;
                qDebug() << startY;
            #endif
            
            tryMove(curPiece[t], startX, 1);
            break;
        }
    }
}


/**
    Tries to do a move with the current piece and the user input
    @return bool value
    @param &newPiece the tetrix piece
    @param newX new X-pos for the block
    @param newY new Y-pos for the block
**/

bool GameGrid::tryMove(const TetrixPiece &newPiece, int newX, int newY)
{
    for (int i = 0; i < 4; ++i)
    {
        int x = newX + newPiece.x(i);
        int y = newY - newPiece.y(i);
        if (x < 0 || x >= BoardWidth || y < 0 || y >= BoardHeight)
        return false;
    }

    curPiece[t] = newPiece;
    startX = newX;
    startY = newY;
    update();
    return true;
}

