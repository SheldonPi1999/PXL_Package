/*
 * This file is part of Jens Vanhulst & Kasper toetenel.
 *
 * Developed for the C++ Object-Oriented-Programming Project.
 * This product includes software developed by the LSST Project
 * (https://www.lsst.org).
 * See the COPYRIGHT file at the top-level directory of this distribution
 * for details of code ownership.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef STACKCONTROLLER_H
#define STACKCONTROLLER_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QMediaPlayer>
#include <QMediaPlaylist>

#include "menu.h"
#include "gamesetup.h"
#include "leaderboard.h"
#include "settings.h"
#include "language.h"
#include "support.h"
#include "theme.h"
#include "rules.h"
#include "gamewindow.h"

class StackController : public QMainWindow
{
    Q_OBJECT

public:
    StackController(QWidget *parent = nullptr);
    ~StackController();

public slots:
    void showLeaderboard();
    void showNewGame();
    void showContinue();
    void showSettings();
    void exit();
    void toggleSound_menu();
    void toggleSound_settings();
    void back_to_menu();
    void setFullscreen();
    void showLanguage();
    void showRules();
    void showSupport();
    void showTheme();

private:
    Menu *menu;
    Gamesetup *gamesetup;
    Leaderboard *leaderboard;
    Settings *settings;
    Language *language;
    Support *support;
    Theme *theme;
    Rules *rules;
    GameWindow *gamewindow;

    QMediaPlayer *mediaplayer;
    QMediaPlaylist *playlist;
    QStackedWidget *stackedWidget;
};
#endif // STACKCONTROLLER_H
