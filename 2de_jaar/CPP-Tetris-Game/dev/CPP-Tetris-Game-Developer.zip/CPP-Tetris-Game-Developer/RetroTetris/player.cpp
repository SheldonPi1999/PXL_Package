/*
 * This file is part of Jens Vanhulst & Kasper toetenel.
 *
 * Developed for the C++ Object-Oriented-Programming Project.
 * This product includes software developed by the LSST Project
 * (https://www.lsst.org).
 * See the COPYRIGHT file at the top-level directory of this distribution
 * for details of code ownership.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include <iostream>
#include <player.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <string>

using namespace std;

/**
   Writes data to a CSV file

    @param string path - the path where the file is/ created
    @param string d1 - Name of the player
    @param string d2 - score of the player
    @param string d3 - highscore of the player
    @return none
*/
void player::writeToCSV(string path, string d1, int d2, int d3) {
  // open file pointer
  fstream fp;
  // opens an existing csv file or creates a new file.
  fp.open(path, ios::out | ios::app);
  // Insert the data to file
  fp << d1 << ", " << d2 << ", " << d3 << ", " << "\n";
  //Close the file
  fp.close();
}

/**
    Function to parse a CSV file

    @param string path - the path of the input file
    @return none
*/
void player::readFromCSV(string path) {
  string line;
  vector < string > row;
  ifstream file(path);
  if (file.is_open()) {
    while (getline(file, line)) {
      stringstream ss(line);
      while (getline(ss, line, ',')) {
        row.push_back(line); // write item to array
      }
    }
  }
  for (int i = 0; i < (int) row.size(); i++) {
    //cout<< row.at(i) <<endl;
    //cout << row[3].at(i) <<endl;
    cout << "Reading from file" << endl << "Name :" << row[i].at(i) << endl << "Score :" << row[i].at(i) << endl << "Highscore :" << row[i].at(i) << endl;
  }
}
