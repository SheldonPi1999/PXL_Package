/*
 * This file is part of Jens Vanhulst & Kasper toetenel.
 *
 * Developed for the C++ Object-Oriented-Programming Project.
 * This product includes software developed by the LSST Project
 * (https://www.lsst.org).
 * See the COPYRIGHT file at the top-level directory of this distribution
 * for details of code ownership.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef TETRIXBOARD_H
#define TETRIXBOARD_H

#include <QBasicTimer>
#include <QFrame>
#include <QPointer>
#include <player.h>

#include "tetrixpiece.h"

QT_BEGIN_NAMESPACE
class QLabel;
QT_END_NAMESPACE


class GameGrid : public QFrame
{
    Q_OBJECT

public:
    GameGrid(QWidget *parent = nullptr);

public slots:
    void start();
    void end();
signals:
    void scoreChanged(int score);

protected:
    void paintEvent(QPaintEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;

private:
    // Checks if game is started or not;
    bool isStarted;

    void newPiece();

    enum{BoardWidth = 10, BoardHeight = 22};

    unsigned short int squareWidth()  {return contentsRect().width() / BoardWidth;}
    unsigned short int squareHeight() {return contentsRect().height() / BoardHeight;}

    void drawSquare(QPainter &painter, int x, int y);

    TetrixPiece curPiece[55];
    TetrixPiece nextPiece;

    unsigned short int t = 0;
    unsigned short int startX;
    unsigned short int startY;
    unsigned long int score;
    player *pl;

    bool tryMove(const TetrixPiece &newPiece, int newX, int newY);
};
//! [1]

#endif
