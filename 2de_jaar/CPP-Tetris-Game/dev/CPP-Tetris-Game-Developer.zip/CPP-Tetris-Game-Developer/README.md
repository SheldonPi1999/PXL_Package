[x] - clean main (i.e. nothing in the main that shoud be in a class)
  * DONE

[x] - useful class (explain why)
  * Stackcontroller = main
  * elke view is appart in een class


[x] - useful and correct encapsulation (explain why)
  * Public, private ...

[x] - useful and correct inheritance (explain why) <!-- TO BE CHECKED -->
  * leaderboard -> ln 10 -> ( public widget ) 

[x] - correct base class
  * Classes in header files

[x] - no globals, but statics if needed
  * DONE

[x] - everything in one or more self-made namespace(s) 
  * DONE

[x] - maintanability by good function naming and/or comments everywhere

[x] - seperate header files
  * DONE

[x] - 2 unsigned chars or other better usage of memory efficient type 

[x] - at least 4 useful bool 
  * gamewindow.h -> isStarted
  * settings.cpp & stackcontroller.cpp -> in functies bool voor button

[x] - useful pointer declaration and usage
  * Stackcontroller => ln 44->57
  * Stackcontroller.cpp => implemtations

[x] - dynamic memory allocation (new)
  *  stackcontroller => ln 25 -> 37;

[x] - dynamic memory removing (delete)
  * Deconstructors van alle classes
  * settings.h => ln 21 

[x] - 2 (modern) call-by-references
  * gamegrid => ln 142 & 83

[x] - useful string class usage 
  * player.h 
    
[x] - useful usage of enum
  * blocks.h => ln 4 (storage of block shapes)
    
[x] - useful Qt class
  * QWidgets, QPushbutton
    
[x] - useful function overriding (non virtual)
  * gamegrid.h => ln 76, 77

[x] - useful usage of nullptr
  * support.h => ln 15 parent

[x] - useful usage of (modern) file-I/O 
  * player.cpp => Read/write to CSV

[x] - useful usage of signals/slots
  * Stackcontroller.h ->ln 29 -> 41

[x] - one complete project that compiles and does not crash
  * DONE

[x] - usage of a GUI
  * DONE

[x] - at least 2 default constructors <!-- One More Plese -->
  * blocks.h -> ln 10
   
[x] - at least 2 specific constructors
  * Stackcontroller.h => 25
  * Player.h => 18
    
[x] - member initialization in constructors (the stuff behind a colon)
  * player.h

[x] - at least 2 destructors
  * Elke header file

[x] - useful useage of this (if the code does not work without it)
  * Stackcontroller.cpp => ln 54 -> 73 -> connect functions  

[x] - a nice extra that you think that should deserve grading (stuff you put time in and is not rewarded by an item above)

[x] - useful member function
  * player.h -> void writeToCSV
  * blocks.h -> void setRandomShape() -> ln 12

[x] - default values in function definition
  * player.h -> ln 18

[x] - useful member variable
  * player.h -> ln 12->14
  * gamegrid.h -> ln 95 -> 97

[x] - getters and setters for member variables
  * player.h

[x] - correct protections
  * public, private



<!-- 6 -->

[O] - correct abstract base class <!-- TO BE DONE -->

[O] - useful virtual function <!-- TO BE DONE -->

[O] - useful proven (dynamic) polymorphism <!-- TO BE DONE -->

[O] - no mistake in object-oriented programming

[O] - using the best suited type on a lot of places (almost everywhere possible) <!-- TO BE DONE -->

[O] - correctly using const in almost all places (almost everywhere possible) <!-- TO BE DONE -->



<!-- 17 -->

[] - useful container class <!-- TO BE DONE -->

[] - operator overloading 

[] - useful function overloading (non operator)

[] - template function or class

[] - non-type template arguments

[] - friend function or class

[] - correct useage of inline function

[] - useful recursive function

[] - correct usage of command line parameters

[] - useful usage of struct

[] - useful usage of union

[] - multiple inheritance

[] - useful usage of lambda function

[] - robust program that has been extensively tested (proof it with unit tests or integration tests, no monkey testing = ad hoc without documentation or plan)

[] - usage of OpenGL or other 3D engine

[] - useful usage of an external library (not Qt)

[] - project that works with hardware

[] - at least 4 useful const references

[] - nesting of classes