#include "game.h"
#include "ui_game.h"

game::game(QWidget *parent) : QMainWindow(parent) , ui(new Ui::game)
{
    ui->setupUi(this);
    game::showFullScreen();
}


game::~game()
{
    delete ui;
}


// ik denk da da hier ni mag staan ma om te teste is da goe;
int i = 1;

void game::on_btn_pause_clicked()
{

    ui->frame_score->display(i);
    ui->frame_level->display(i);
    i++;

}

void game::on_btn_exit_clicked()
{
    game::close();
}
