/********************************************************************************
** Form generated from reading UI file 'game.ui'
**
** Created by: Qt User Interface Compiler version 5.12.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GAME_H
#define UI_GAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_game
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QGridLayout *grid_game;
    QGridLayout *right_indicators;
    QLabel *lbl_next;
    QLabel *lbl_score;
    QPushButton *btn_exit;
    QSpacerItem *verticalSpacer;
    QPushButton *btn_pause;
    QFrame *frame_next_2_block;
    QVBoxLayout *Level;
    QLabel *lbl_level;
    QLCDNumber *frame_level;
    QSpacerItem *verticalSpacer_2;
    QLCDNumber *frame_score;
    QFrame *frame_next_block;
    QSpacerItem *verticalSpacer_4;
    QGridLayout *game_field;
    QFrame *frame_game_field;
    QGridLayout *left_indicators;
    QLabel *label;
    QFrame *frame_hold_block;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *hs_l_5;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *verticalSpacer_5;
    QSpacerItem *verticalSpacer_6;

    void setupUi(QMainWindow *game)
    {
        if (game->objectName().isEmpty())
            game->setObjectName(QString::fromUtf8("game"));
        game->resize(730, 928);
        game->setStyleSheet(QString::fromUtf8("#game {\n"
"	background-repeat : no-repeat;\n"
"border-image: url(:/assets/grid/assets/bg.png) 0 0 0 0 stretch stretch;\n"
"}\n"
"\n"
""));
        centralwidget = new QWidget(game);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(centralwidget->sizePolicy().hasHeightForWidth());
        centralwidget->setSizePolicy(sizePolicy);
        centralwidget->setMaximumSize(QSize(16777215, 16777215));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        grid_game = new QGridLayout();
        grid_game->setObjectName(QString::fromUtf8("grid_game"));
        grid_game->setHorizontalSpacing(6);
        grid_game->setContentsMargins(0, -1, -1, -1);
        right_indicators = new QGridLayout();
        right_indicators->setObjectName(QString::fromUtf8("right_indicators"));
        lbl_next = new QLabel(centralwidget);
        lbl_next->setObjectName(QString::fromUtf8("lbl_next"));
        lbl_next->setStyleSheet(QString::fromUtf8("QLabel {\n"
"color: rgb(255, 255, 255);\n"
"font-weight : bold;\n"
"}\n"
""));
        lbl_next->setAlignment(Qt::AlignCenter);

        right_indicators->addWidget(lbl_next, 0, 0, 1, 1);

        lbl_score = new QLabel(centralwidget);
        lbl_score->setObjectName(QString::fromUtf8("lbl_score"));
        lbl_score->setStyleSheet(QString::fromUtf8("QLabel {\n"
"color: rgb(255, 255, 255);\n"
"font-weight : bold;\n"
"}\n"
""));
        lbl_score->setAlignment(Qt::AlignCenter);

        right_indicators->addWidget(lbl_score, 6, 0, 1, 1);

        btn_exit = new QPushButton(centralwidget);
        btn_exit->setObjectName(QString::fromUtf8("btn_exit"));

        right_indicators->addWidget(btn_exit, 12, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Minimum);

        right_indicators->addItem(verticalSpacer, 3, 0, 1, 1);

        btn_pause = new QPushButton(centralwidget);
        btn_pause->setObjectName(QString::fromUtf8("btn_pause"));

        right_indicators->addWidget(btn_pause, 11, 0, 1, 1);

        frame_next_2_block = new QFrame(centralwidget);
        frame_next_2_block->setObjectName(QString::fromUtf8("frame_next_2_block"));
        frame_next_2_block->setMinimumSize(QSize(100, 100));
        frame_next_2_block->setStyleSheet(QString::fromUtf8("\n"
"QFrame {\n"
"\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"}"));
        frame_next_2_block->setFrameShape(QFrame::StyledPanel);
        frame_next_2_block->setFrameShadow(QFrame::Raised);

        right_indicators->addWidget(frame_next_2_block, 2, 0, 1, 1);

        Level = new QVBoxLayout();
        Level->setObjectName(QString::fromUtf8("Level"));
        lbl_level = new QLabel(centralwidget);
        lbl_level->setObjectName(QString::fromUtf8("lbl_level"));
        lbl_level->setStyleSheet(QString::fromUtf8("QLabel {\n"
"color: rgb(255, 255, 255);\n"
"font-weight : bold;\n"
"}\n"
""));
        lbl_level->setAlignment(Qt::AlignCenter);

        Level->addWidget(lbl_level);

        frame_level = new QLCDNumber(centralwidget);
        frame_level->setObjectName(QString::fromUtf8("frame_level"));
        frame_level->setMinimumSize(QSize(0, 50));
        frame_level->setStyleSheet(QString::fromUtf8("\n"
"QFrame {\n"
"\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"}"));
        frame_level->setSmallDecimalPoint(false);
        frame_level->setSegmentStyle(QLCDNumber::Flat);
        frame_level->setProperty("intValue", QVariant(0));

        Level->addWidget(frame_level);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        Level->addItem(verticalSpacer_2);


        right_indicators->addLayout(Level, 8, 0, 1, 1);

        frame_score = new QLCDNumber(centralwidget);
        frame_score->setObjectName(QString::fromUtf8("frame_score"));
        frame_score->setMinimumSize(QSize(0, 50));
        frame_score->setStyleSheet(QString::fromUtf8("\n"
"QFrame {\n"
"\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"}"));
        frame_score->setSegmentStyle(QLCDNumber::Flat);

        right_indicators->addWidget(frame_score, 7, 0, 1, 1);

        frame_next_block = new QFrame(centralwidget);
        frame_next_block->setObjectName(QString::fromUtf8("frame_next_block"));
        frame_next_block->setMinimumSize(QSize(100, 100));
        frame_next_block->setStyleSheet(QString::fromUtf8("\n"
"QFrame {\n"
"\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"}"));
        frame_next_block->setFrameShape(QFrame::StyledPanel);
        frame_next_block->setFrameShadow(QFrame::Raised);

        right_indicators->addWidget(frame_next_block, 1, 0, 1, 1);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        right_indicators->addItem(verticalSpacer_4, 13, 0, 1, 1);


        grid_game->addLayout(right_indicators, 0, 4, 1, 1);

        game_field = new QGridLayout();
        game_field->setObjectName(QString::fromUtf8("game_field"));
        frame_game_field = new QFrame(centralwidget);
        frame_game_field->setObjectName(QString::fromUtf8("frame_game_field"));
        frame_game_field->setMinimumSize(QSize(400, 800));
        frame_game_field->setStyleSheet(QString::fromUtf8("#frame_game_field {\n"
"	background-repeat: no-repeat;\n"
"	border-image: url(:/assets/grid/assets/grid_1.png);\n"
"	background-position: center;\n"
"	border-color: rgb(0, 0, 0);\n"
"}"));
        frame_game_field->setFrameShape(QFrame::StyledPanel);
        frame_game_field->setFrameShadow(QFrame::Raised);

        game_field->addWidget(frame_game_field, 0, 0, 1, 1);


        grid_game->addLayout(game_field, 0, 3, 1, 1);

        left_indicators = new QGridLayout();
        left_indicators->setObjectName(QString::fromUtf8("left_indicators"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setStyleSheet(QString::fromUtf8("QLabel {\n"
"color: rgb(255, 255, 255);\n"
"font-weight : bold;\n"
"}\n"
""));
        label->setAlignment(Qt::AlignCenter);

        left_indicators->addWidget(label, 0, 0, 1, 1);

        frame_hold_block = new QFrame(centralwidget);
        frame_hold_block->setObjectName(QString::fromUtf8("frame_hold_block"));
        frame_hold_block->setMinimumSize(QSize(100, 100));
        frame_hold_block->setStyleSheet(QString::fromUtf8("\n"
"QFrame {\n"
"\n"
"background-color: rgb(255, 255, 255);\n"
"\n"
"}"));
        frame_hold_block->setFrameShape(QFrame::StyledPanel);
        frame_hold_block->setFrameShadow(QFrame::Raised);

        left_indicators->addWidget(frame_hold_block, 1, 0, 1, 1);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        left_indicators->addItem(verticalSpacer_3, 2, 0, 1, 1);


        grid_game->addLayout(left_indicators, 0, 2, 1, 1);

        hs_l_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        grid_game->addItem(hs_l_5, 0, 5, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        grid_game->addItem(horizontalSpacer, 0, 0, 1, 1);


        gridLayout->addLayout(grid_game, 1, 0, 1, 1);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::MinimumExpanding);

        gridLayout->addItem(verticalSpacer_5, 0, 0, 1, 1);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::MinimumExpanding);

        gridLayout->addItem(verticalSpacer_6, 2, 0, 1, 1);

        game->setCentralWidget(centralwidget);

        retranslateUi(game);

        QMetaObject::connectSlotsByName(game);
    } // setupUi

    void retranslateUi(QMainWindow *game)
    {
        game->setWindowTitle(QApplication::translate("game", "game", nullptr));
        lbl_next->setText(QApplication::translate("game", "NEXT", nullptr));
        lbl_score->setText(QApplication::translate("game", "SCORE", nullptr));
        btn_exit->setText(QApplication::translate("game", "Exit", nullptr));
        btn_pause->setText(QApplication::translate("game", "Pause", nullptr));
        lbl_level->setText(QApplication::translate("game", "LEVEL", nullptr));
        label->setText(QApplication::translate("game", "HOLD", nullptr));
    } // retranslateUi

};

namespace Ui {
    class game: public Ui_game {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GAME_H
