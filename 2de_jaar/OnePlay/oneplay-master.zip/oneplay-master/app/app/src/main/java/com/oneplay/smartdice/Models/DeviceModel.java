package com.oneplay.smartdice.Models;

import com.oneplay.smartdice.R;

public class DeviceModel {
    private String deviceName, deviceIP, deviceVersion;
    private int deviceImage, deviceColor;

    public String getDeviceName() { return deviceName; }
    public void setDeviceName(String deviceName) { this.deviceName = deviceName; }

    public String getDeviceIP() { return deviceIP; }
    public void setDeviceIP(String deviceIP) { this.deviceIP = deviceIP; }

    public String getDeviceVersion() { return deviceVersion; }
    public void setDeviceVersion(String deviceVersion) { this.deviceVersion = deviceVersion; }

    public int getDeviceImage() { return deviceImage; }
    public void setDeviceImage(int deviceImage) { this.deviceImage = deviceImage; }

    public void setDeviceColor(int deviceColor) { this.deviceColor = deviceColor; }
    public int getCardColor() { return deviceColor;}
}
