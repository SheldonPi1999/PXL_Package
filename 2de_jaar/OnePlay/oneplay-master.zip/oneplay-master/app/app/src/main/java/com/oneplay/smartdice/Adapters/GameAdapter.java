package com.oneplay.smartdice.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.oneplay.smartdice.Activities.Games.KnockOffActivity;
import com.oneplay.smartdice.Holders.GameHolder;
import com.oneplay.smartdice.Interfaces.ItemClickListener;
import com.oneplay.smartdice.Models.GameModel;
import com.oneplay.smartdice.R;
import com.oneplay.smartdice.Utils.GameFilter;

import java.util.ArrayList;

public class GameAdapter extends RecyclerView.Adapter<GameHolder> implements Filterable {

    private Context mContext;
    public ArrayList<GameModel> gameModels, filterList;
    private GameFilter filter;

    public GameAdapter(Context mContext, ArrayList<GameModel> gameModels) {
        this.mContext = mContext;
        this.gameModels = gameModels;
        this.filterList = gameModels;
    }

    @NonNull
    @Override
    public GameHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row, null);
        return new GameHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final GameHolder holder, int position) {
        holder.mGameTitle.setText(gameModels.get(position).getGameTitle());
        holder.mGameDescription.setText(gameModels.get(position).getGameDescription());
        holder.mGameImage.setImageResource(gameModels.get(position).getGameImage());

        holder.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickListener(View view, int position) {

                String gameTitle = gameModels.get(position).getGameTitle();
                switch (gameTitle) {
                    case "Knock Off":
                        Intent KnockOff = new Intent(mContext, KnockOffActivity.class);
                        mContext.startActivity(KnockOff);
                        break;
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return gameModels.size();
    }

    @Override
    public Filter getFilter() {
        if (filter == null) {
            filter = new GameFilter(filterList, this);
        }
        return filter;
    }
}
