package com.oneplay.smartdice.Utils;

import android.widget.Filter;

import com.oneplay.smartdice.Adapters.GameAdapter;
import com.oneplay.smartdice.Models.GameModel;

import java.util.ArrayList;

public class GameFilter extends Filter {

    private ArrayList<GameModel> filterList;
    private GameAdapter adapter;

    public GameFilter(ArrayList<GameModel> filterList, GameAdapter adapter) {
        this.filterList = filterList;
        this.adapter = adapter;
    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {

        FilterResults results = new FilterResults();

        if (constraint != null && constraint.length() > 0) {
            constraint = constraint.toString().toUpperCase();

            ArrayList<GameModel> filterModels = new ArrayList<>();

            for (int i = 0; i < filterList.size(); i++ ) {
                if ( filterList.get(i).getGameTitle().toUpperCase().contains(constraint)) {
                    filterModels.add(filterList.get(i));
                }
            }
            results.count = filterModels.size();
            results.values = filterModels;
        } else {
            results.count = filterList.size();
            results.values = filterList;
        }
        return results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
        adapter.gameModels = (ArrayList<GameModel>) results.values;
        adapter.notifyDataSetChanged();
    }
}
