package com.oneplay.smartdice.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.oneplay.smartdice.R;
import com.oneplay.smartdice.SearchActivity;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_SCREEN_DURATION = 3000;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //make application fullscreen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        sharedPreferences = getApplicationContext().getSharedPreferences(SearchActivity.USER_PREFERENCE, MODE_PRIVATE);
        checkNightModeActivated();

        setContentView(R.layout.activity_splash);


            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent search = new Intent(getApplicationContext(), SearchActivity.class);
                    startActivity(search);
                    finish();
                }
            }, SPLASH_SCREEN_DURATION);
    }

    private void checkNightModeActivated() {
        if (sharedPreferences.getBoolean(SearchActivity.DARK_MODE_ENABLED, false)) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }
    }
}
