package com.oneplay.smartdice.Activities.Games;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.oneplay.smartdice.R;

import org.json.JSONException;
import org.json.JSONObject;

public class KnockOffActivity extends AppCompatActivity {

    ImageView image;
    CollapsingToolbarLayout collapsingToolbarLayout;
    MaterialToolbar toolbar;

    TextInputEditText p1KnockOffNumber, p2KnockOffNumber;
    MaterialButton buttonRoll;
    private static final String TAG = KnockOffActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_knockoff);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        collapsingToolbarLayout = findViewById(R.id.collapsing);
        image = findViewById(R.id.game_image);

        //image.setImageResource(R.drawable.yathzee);

        collapsingToolbarLayout.setExpandedTitleTextAppearance(R.style.ExpandedAppbar);
        collapsingToolbarLayout.setCollapsedTitleTextAppearance(R.style.CollapsedAppbar);
        p1KnockOffNumber = findViewById(R.id.p1KnockOffNumber);
        p2KnockOffNumber = findViewById(R.id.p2KnockOffNumber);
        buttonRoll = findViewById(R.id.roll);

        collapsingToolbarLayout.setTitle("Knock off");

        buttonRoll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                postValues();
            }
        });
    }

    private void postValues() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JSONObject object = new JSONObject();
        try {
            object.put("p1KnockOutScore",p1KnockOffNumber.getText());
            object.put("p2KnockOutScore",p2KnockOffNumber.getText());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String url = "http://192.168.4.1/";
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, object,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_LONG).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        requestQueue.add(jsonObjectRequest);
    }
}
