package com.oneplay.smartdice.Interfaces;

import android.view.View;

public interface ItemClickListener {
    void onItemClickListener(View view, int position);
}

