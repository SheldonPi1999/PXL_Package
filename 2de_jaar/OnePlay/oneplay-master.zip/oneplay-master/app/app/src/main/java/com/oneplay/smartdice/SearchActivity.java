package com.oneplay.smartdice;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.oneplay.smartdice.Activities.GameListActivity;
import com.oneplay.smartdice.Activities.SettingsActivity;
import com.oneplay.smartdice.Adapters.DeviceAdapter;
import com.oneplay.smartdice.Dialogs.WifiDialog;
import com.oneplay.smartdice.Models.DeviceModel;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SearchActivity extends AppCompatActivity {

    private SearchNetwork searchNetwork;
    public static TextView searchStatus;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ImageView noDeviceImage;
    private ImageView swipeIndicator;

    private DeviceAdapter deviceAdapter;
    private RecyclerView deviceRecycler;

    private ArrayList<DeviceModel> deviceModels;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    public static final String USER_PREFERENCE = "USER_PREFERENCE";
    public static final String USER_OPENED_INTRO = "USER_OPENED_INTRO";
    public static final String DEVICE_IP_KEY = "DEVICE_IP";
    public static final String DEVICE_SSID_KEY = "DEVICE_SSID";
    public static final String DEVICE_PICKED_KEY = "DEVICE_PICKED";
    public static final String DARK_MODE_ENABLED = "DARK_MODE_ENABLED";

    private static boolean firstRun = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        sharedPreferences = getApplicationContext().getSharedPreferences(USER_PREFERENCE, MODE_PRIVATE);

        if (firstRun) clearDevicePreferences();
        firstRun = false;

        super.onCreate(savedInstanceState);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        setContentView(R.layout.activity_search);

        //Link UI -> Code
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNav);
        searchStatus = findViewById(R.id.search_status);
        progressBar = findViewById(R.id.search_progress);
        swipeRefreshLayout = findViewById(R.id.refresh_layout);
        noDeviceImage = findViewById(R.id.no_device_found);
        swipeIndicator = findViewById(R.id.swipe_indicator);

        deviceRecycler = findViewById(R.id.device_recycler);

        swipeIndicator.setVisibility(View.VISIBLE);


        //Create an active indicator when clicked
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.device_tab:
                        break;

                    case R.id.games_tab:
                        Intent gameList = new Intent(SearchActivity.this, GameListActivity.class);
                        gameList.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(gameList);
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        finish();
                        break;

                    case R.id.settings_tab:
                        Intent settings = new Intent(getApplicationContext(), SettingsActivity.class);
                        settings.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(settings);
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        finish();
                        break;
                }
                return false;
            }
        });

        if (sharedPreferences.getBoolean(DEVICE_PICKED_KEY, false)) {
            viewSelectedDevices();
        } else {
            deviceRecycler.setVisibility(View.GONE);
        }

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                //Clear the device list if the user want to search again
                swipeIndicator.setVisibility(View.GONE);

                if ( sharedPreferences.getBoolean(DEVICE_PICKED_KEY, false)) {
                    clearDevicePreferences();
                }

                //Clear the no_device_found_image
                noDeviceImage.setVisibility(View.GONE);
                searchStatus.setText(getResources().getString(R.string.DASHBOARD_PRI_SEARCH));

                //Run the search task
                searchNetwork = new SearchNetwork(SearchActivity.this);
                searchNetwork.execute();

                swipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    public static void setStatusSelected() {
        searchStatus.setText("1 device selected");
    }

    private void viewSelectedDevices() {
        ArrayList<DeviceModel> deviceModels =  new ArrayList<>();
        DeviceModel device = new DeviceModel();
        device.setDeviceName(sharedPreferences.getString(DEVICE_SSID_KEY, "Error getting name"));
        device.setDeviceIP(sharedPreferences.getString(DEVICE_IP_KEY, "Error getting ip"));
        device.setDeviceVersion("1.0");
        device.setDeviceImage(R.drawable.thumbnail);
        device.setDeviceColor(getResources().getColor(R.color.selectedColor));
        deviceModels.add(device);

        searchStatus.setText("1 device selected");
        swipeIndicator.setVisibility(View.GONE);

        deviceRecycler.setLayoutManager(new LinearLayoutManager(SearchActivity.this));
        deviceAdapter = new DeviceAdapter(SearchActivity.this, deviceModels);
        deviceRecycler.setAdapter(deviceAdapter);
    }

    private void clearDevicePreferences() {
        editor = sharedPreferences.edit();
        editor.remove(DEVICE_IP_KEY);
        editor.remove(DEVICE_PICKED_KEY);
        editor.remove(DEVICE_SSID_KEY);
        editor.apply();
    }

    private class SearchNetwork extends AsyncTask<Void, Void, String> {

        private static final String TAG = "SEARCH_NETWORK";
        private String mSSID;
        private String mDeviceIP;

        private String[] esp_macs = new String[]{"ee:fa:bc:0e:ad:1", "5e:cf:7f:63:3c:41"};
        List<String> macList = Arrays.asList(esp_macs);

        WifiManager mWifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        WifiDialog wifiDialog = new WifiDialog("Wi-Fi is disabled", "Please enable Wi-fi and try again");
        WifiDialog notConnectedToNetwork = new WifiDialog("Not connected to any network", "Please connect to the smart dice's network and try again .");

        //Public
        private SearchNetwork(Context context) { WeakReference<Context> mContextRef = new WeakReference<>(context); }

        @Override
        protected void onPreExecute() {
            if (!mWifiManager.isWifiEnabled() || !isConnectedToNetwork()) {
                searchNetwork.cancel(true);
            } else {
                progressBar.setVisibility(View.VISIBLE);
                searchStatus.setText(getResources().getString(R.string.DASHBOARD_PRI_SEARCHING));
            }
        }

        @Override
        protected String doInBackground(Void... voids) {
            String host = "192.168.4.1";
            mSSID = mWifiManager.getConnectionInfo().getSSID().replaceAll("^\"|\"$", "");

            try {
                if (InetAddress.getByName(host).isReachable(100)) {
                    String macAddress = getMacAddressFromIP(host);
                    if (macList.contains(macAddress)) {
                        mDeviceIP = host;
                        return macAddress;
                    }
                }
            } catch (UnknownHostException e) {
                e.printStackTrace();
                return "NO DEVICE FOUND";
            } catch (IOException e) {
                e.printStackTrace();
                return "NO DEVICE FOUND";
            }
            return "NO DEVICE FOUND";
        }

        @Override
        protected void onPostExecute(@NonNull String result) {
            if (result.equals("ERROR") || result.equals("NO DEVICE FOUND")) {
                setAmountOfDevicesUI(0);
            } else if (result.matches("..:..:..:..:..:..")) {
                viewFoundDevice(this.getSSID(), this.getDeviceIP());
            } else {
                setAmountOfDevicesUI(0);
            }
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
            noDeviceImage.setVisibility(View.VISIBLE);
            if (!mWifiManager.isWifiEnabled()) {
                wifiDialog.show(getSupportFragmentManager(), "wifi_disabled");
            } else {
                notConnectedToNetwork.show(getSupportFragmentManager(), "no_network");
            }
        }

        private String getDeviceIP() {
            return mDeviceIP;
        }
        private String getMacAddressFromIP(@NonNull String ipFinding) {
            BufferedReader bufferedReader = null;
            String line;
            String[] splitted;

            try {
                bufferedReader = new BufferedReader(new FileReader("/proc/net/arp"));
                while ((line = bufferedReader.readLine()) != null) {
                     splitted = line.split(" +");

                    if (splitted.length >= 4) {
                        String foundIP = splitted[0];
                        String foundMAC = splitted[3];

                        if (foundMAC.matches("..:..:..:..:..:..")) {
                            if (foundIP.equalsIgnoreCase(ipFinding)) {
                                return foundMAC;
                            }
                        }
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return "00:00:00:00";
        }
        private String getSSID() { return mSSID; }

        private void setAmountOfDevicesUI(int amountOfDevices) {
            if (amountOfDevices == 0) {
                searchStatus.setText(getResources().getString(R.string.DASHBOARD_PRI_NO_DEVICE));
                deviceRecycler.setVisibility(View.GONE);
                progressBar.setVisibility(View.GONE);
                noDeviceImage.setVisibility(View.VISIBLE);

            } else if (amountOfDevices == 1) {
                searchStatus.setText(getResources().getString(R.string.DASHBOARD_PRI_SINGLE_DEVICE));
                progressBar.setVisibility(View.GONE);
                noDeviceImage.setVisibility(View.GONE);
                deviceRecycler.setVisibility(View.VISIBLE);
            }
        }

        private boolean checkDarkMode() { return sharedPreferences.getBoolean(DARK_MODE_ENABLED, false); }

        private void viewFoundDevice(String ssid, String ip) {
            ArrayList<DeviceModel> deviceModels =  new ArrayList<>();
            DeviceModel device = new DeviceModel();
            device.setDeviceName(ssid);
            device.setDeviceImage(R.drawable.thumbnail);
            device.setDeviceIP(ip);
            device.setDeviceVersion("1.0");

            if ( checkDarkMode() ) {
                device.setDeviceColor(getResources().getColor(R.color.white));
            } else {
                device.setDeviceColor(getResources().getColor(R.color.primaryColor));
            }

            deviceModels.add(device);
            deviceRecycler.setLayoutManager(new LinearLayoutManager(SearchActivity.this));
            deviceAdapter = new DeviceAdapter(SearchActivity.this, deviceModels);
            deviceRecycler.setAdapter(deviceAdapter);

            //Set ui depending on the amount of found devices
            setAmountOfDevicesUI(deviceModels.size());
        }

        private boolean isConnectedToNetwork() {
            ConnectivityManager manager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = manager.getActiveNetworkInfo();
            return networkInfo != null && networkInfo.isConnected();
        }
    } // End of class

}
