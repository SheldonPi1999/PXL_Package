package com.oneplay.smartdice.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.oneplay.smartdice.Activities.GameListActivity;
import com.oneplay.smartdice.Holders.DeviceHolder;
import com.oneplay.smartdice.Interfaces.ItemClickListener;
import com.oneplay.smartdice.Models.DeviceModel;
import com.oneplay.smartdice.R;
import com.oneplay.smartdice.SearchActivity;

import java.util.ArrayList;


public class DeviceAdapter extends RecyclerView.Adapter<DeviceHolder> {
    private Context mContext;
    private ArrayList<DeviceModel> mDeviceModels;
    private SharedPreferences.Editor editor;

    public DeviceAdapter(Context context, ArrayList<DeviceModel> deviceModels) {
        this.mContext = context;
        this.mDeviceModels = deviceModels;
    }

    @NonNull
    @Override
    public DeviceHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.device_item, null);
        return new DeviceHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final DeviceHolder holder, int position) {
        String ip = "IP : " + mDeviceModels.get(position).getDeviceIP();
        String version = "Version : " + mDeviceModels.get(position).getDeviceVersion();

        holder.mDeviceName.setText(mDeviceModels.get(position).getDeviceName());
        holder.mDeviceIP.setText(ip);
        holder.mDeviceVersion.setText(version);
        holder.mDeviceImage.setImageResource(mDeviceModels.get(position).getDeviceImage());
        holder.mDeviceCard.setStrokeColor(mDeviceModels.get(position).getCardColor());

        SharedPreferences preferences = mContext.getSharedPreferences(SearchActivity.USER_PREFERENCE, Context.MODE_PRIVATE);
        editor = preferences.edit();

        holder.setItemClickListener(new ItemClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onItemClickListener(View view, int position) {
                editor.putBoolean(SearchActivity.DEVICE_PICKED_KEY, true);
                editor.putString(SearchActivity.DEVICE_IP_KEY, mDeviceModels.get(position).getDeviceIP());
                editor.putString(SearchActivity.DEVICE_SSID_KEY, mDeviceModels.get(position).getDeviceName());
                editor.apply();

                holder.mDeviceCard.setStrokeColor(mContext.getResources().getColor(R.color.selectedColor));

                String deviceName = mDeviceModels.get(position).getDeviceName();
                if (deviceName != null) {
                    SearchActivity.setStatusSelected();
                    Intent games = new Intent(mContext, GameListActivity.class);
                    games.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    mContext.startActivity(games);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDeviceModels.size();
    }
}
