package com.oneplay.smartdice.Holders;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.oneplay.smartdice.Interfaces.ItemClickListener;
import com.oneplay.smartdice.R;

public class GameHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    public ImageView mGameImage;
    public TextView mGameTitle, mGameDescription;
    private ItemClickListener itemClickListener;

    public GameHolder(@NonNull View itemView) {
        super(itemView);

        this.mGameImage = itemView.findViewById(R.id.game_image);
        this.mGameTitle = itemView.findViewById(R.id.game_title);
        this.mGameDescription = itemView.findViewById(R.id.game_description);

        itemView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        this.itemClickListener.onItemClickListener(v , getLayoutPosition());
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }
}
