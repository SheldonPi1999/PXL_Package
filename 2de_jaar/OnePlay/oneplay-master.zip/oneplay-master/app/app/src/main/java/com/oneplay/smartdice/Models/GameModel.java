package com.oneplay.smartdice.Models;

import java.util.Comparator;

public class GameModel {
    private String gameTitle,gameDescription;
    private int gameImage;

    public String getGameTitle() {
        return gameTitle;
    }

    public void setGameTitle(String gameTitle) {
        this.gameTitle = gameTitle;
    }

    public String getGameDescription() {
        return gameDescription;
    }

    public void setGameDescription(String gameDescription) {
        this.gameDescription = gameDescription;
    }

    public int getGameImage() {
        return gameImage;
    }

    public void setGameImage(int gameImage) {
        this.gameImage = gameImage;
    }

    public static final Comparator<GameModel> BY_TITLE_ASCENDING = new Comparator<GameModel>() {
        @Override
        public int compare(GameModel o1, GameModel o2) {
            return o1.getGameTitle().compareTo(o2.getGameTitle());
        }
    };

    public static final Comparator<GameModel> BY_TITLE_DESCENDING = new Comparator<GameModel>() {
        @Override
        public int compare(GameModel o1, GameModel o2) {
            return o2.getGameTitle().compareTo(o1.getGameTitle());
        }
    };
}