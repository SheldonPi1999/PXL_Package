package com.oneplay.smartdice.Activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.oneplay.smartdice.Adapters.GameAdapter;
import com.oneplay.smartdice.Models.GameModel;
import com.oneplay.smartdice.R;
import com.oneplay.smartdice.SearchActivity;

import java.util.ArrayList;
import java.util.Collections;

public class GameListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private GameAdapter gameAdapter;

    private SharedPreferences preferences;
    private SharedPreferences deviceChosen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_list);

        //Link UI -> Code
        MaterialToolbar toolbar = findViewById(R.id.game_list_toolbar);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNav);
        TextView errorMessage = findViewById(R.id.error_message);
        recyclerView = findViewById(R.id.recyclerView);

        //Setup toolbar
        setSupportActionBar(toolbar);

        //Setup bottom navigation view
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(1);
        menuItem.setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.device_tab:
                        Intent device = new Intent(getApplicationContext(), SearchActivity.class);
                        device.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(device);
                        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                        finish();
                        break;

                    case R.id.games_tab:
                        break;

                    case R.id.settings_tab:
                        Intent settings = new Intent(getApplicationContext(), SettingsActivity.class);
                        settings.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(settings);
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        finish();
                        break;
                }
                return false;
            }
        });

        preferences = getApplicationContext().getSharedPreferences("GameSort", MODE_PRIVATE);
        deviceChosen = getApplicationContext().getSharedPreferences(SearchActivity.USER_PREFERENCE, MODE_PRIVATE);

        if (deviceChosen.getBoolean(SearchActivity.DEVICE_PICKED_KEY, false)) {
            getGameList();
        } else {
            recyclerView.setVisibility(View.GONE);
            errorMessage.setVisibility(View.VISIBLE);
        }
    }

    private void getGameList() {
        ArrayList<GameModel> gameModels = new ArrayList<>();
        GameModel m;
        m = new GameModel();
        m.setGameTitle("Knock Off");
        m.setGameDescription("Battle with 2 dices");
        //m.setGameImage(R.drawable.yathzee);
        gameModels.add(m);

        String mSortSetting = preferences.getString("GameSort", "Ascending");

        if (mSortSetting.equals("Ascending")) {
            Collections.sort(gameModels, GameModel.BY_TITLE_ASCENDING);
        } else if (mSortSetting.equals("Descending")) {
            Collections.sort(gameModels, GameModel.BY_TITLE_DESCENDING);
        }

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        gameAdapter = new GameAdapter(this, gameModels);
        recyclerView.setAdapter(gameAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);

        MenuItem item = menu.findItem(R.id.search);

        if (deviceChosen.getBoolean(SearchActivity.DEVICE_PICKED_KEY, false)) {
            androidx.appcompat.widget.SearchView searchView = (androidx.appcompat.widget.SearchView) item.getActionView();
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    gameAdapter.getFilter().filter(query);
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    gameAdapter.getFilter().filter(newText);
                    return false;
                }
            });
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.sorting) {
            sortDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void sortDialog() {
        String[] options = {"Ascending", "Descending"};
        android.app.AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Sort By")
                .setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putString("GameSort", "Ascending");
                            editor.apply();
                            getGameList();
                        }
                        if (which == 1) {
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putString("GameSort", "Descending");
                            editor.apply();
                            getGameList();
                        }
                    }
                });

        builder.create().show();
    }
}
