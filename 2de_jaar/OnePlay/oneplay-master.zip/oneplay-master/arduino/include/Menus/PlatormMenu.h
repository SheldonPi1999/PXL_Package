#ifndef PLATFORM_MENU_H
#define PLATFORM_MENU_H

#include <Adafruit_ST7735.h>
#include <Arduino.h>

class PlatormMenu
{
private:
  PlatormMenu() = default;
  ~PlatormMenu() = default;
  PlatormMenu(const PlatormMenu& ) = delete;

  const PlatormMenu& operator=(const PlatormMenu&) = delete;

public:
  byte counter = 0;
  static PlatormMenu& getInstance();
  void displayMenu(Adafruit_ST7735& screen, byte i);
};

PlatormMenu& PlatormMenu::getInstance() 
{
  static PlatormMenu instance;
  return instance;
}

void PlatormMenu::displayMenu(Adafruit_ST7735& screen, byte i)
{
  screen.fillScreen(ST77XX_BLACK);

  switch (i)
  {
  case 0:
    screen.fillRect(10, 48, 65, 32, ST77XX_GREEN);
    screen.fillRect(85, 48, 60, 32, ST77XX_WHITE);

    screen.setTextSize(2);
    screen.setTextColor(ST77XX_WHITE);

    screen.setCursor(25, 55);
    screen.println("APP");

    screen.setTextSize(1);
    screen.setTextColor(ST77XX_BLACK);

    screen.setCursor(85, 60);
    screen.println("STANDALONE");
    break;
  
  case 1:
    screen.fillRect(10, 48, 65, 32, ST77XX_WHITE);
    screen.fillRect(85, 48, 60, 32, ST77XX_GREEN);

    screen.setTextSize(2);
    screen.setTextColor(ST77XX_BLACK);

    screen.setCursor(25, 55);
    screen.println("APP");

    screen.setTextSize(1);
    screen.setTextColor(ST77XX_WHITE);

    screen.setCursor(85, 60);
    screen.println("STANDALONE");
    break;
  
  default:
    break;
  }
}

#endif
