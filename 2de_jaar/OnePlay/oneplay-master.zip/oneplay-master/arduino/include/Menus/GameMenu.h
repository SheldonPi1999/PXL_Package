#ifndef GAME_MENU_H
#define GAME_MENU_H

#include <Adafruit_ST7735.h>
#include <Arduino.h>

#include "Games/Boggle.h"
#include "Games/Dice.h"
#include "Games/Dice_Color.h"
#include "Games/Dice_Letter.h"
#include "Games/Dice_Shape.h"
#include "Games/Ganzenbord.h"

class GameMenu
{
private:
  Dice *dice;
  Boggle *boggle;
  Ganzenbord *ganzenbord;
  DiceLetter *diceLetter;
  DiceColor *diceColor;
  DiceShape *diceShape;
  
  
  std::vector<String> items { "Normal Dice", "Dice w/ letters", "Dice w/ colors", "Dice w/ shapes","Boggle"};

  GameMenu() = default;
  ~GameMenu() = default;
  GameMenu(const GameMenu&) = delete;

  const GameMenu& operator=(const GameMenu&) = delete;

public:
  static GameMenu& getInstance();

  byte counter = 0;
  void displayMenu(Adafruit_ST7735& screen, byte i);
  void playGame(Adafruit_ST7735& screen, byte i);

};

GameMenu& GameMenu::getInstance()
{
  static GameMenu instance;
  return instance;
}

void GameMenu::displayMenu(Adafruit_ST7735& screen, byte i)
{
  String gameNumber = "GAME " + static_cast<String>(i + 1);

  screen.fillScreen(ST77XX_WHITE);
  if (i != 0)
  {
    for (int i = 0; i < 4; i++)
    {
      //Left Menu Arrow
      screen.drawLine(5 + i, 64, 20 + i, 48, ST77XX_BLACK);
      screen.drawLine(5 + i, 64, 20 + i, 80, ST77XX_BLACK);
    }
  }

  if (i != items.size() - 1)
  {
    for (int i = 0; i < 4; i++)
    {
      //Right Menu Arrow
      screen.drawLine(155 - i, 64, 140 - i, 48, ST77XX_BLACK);
      screen.drawLine(155 - i, 64, 140 - i, 80, ST77XX_BLACK);
    }
  }

  // Mid Text (BIG)
  screen.setTextSize(2);
  screen.setTextColor(ST77XX_RED);
  screen.setCursor(45, 50);
  screen.println(gameNumber);

  // Mid Text (SMALL)
  screen.setTextSize(1);
  screen.setTextColor(ST77XX_BLACK);
  screen.setCursor(45, 70);
  screen.println(this->items.at(i));
}

void GameMenu::playGame(Adafruit_ST7735& screen, byte i)
{
  switch (i)
  {
  case 0:
    this->dice = new Dice(screen);
    break;
  
  case 1:
    this->diceLetter = new DiceLetter(screen);
    break;
  
   case 2:
    this->diceColor = new DiceColor(screen);
    break;
  
  case 3:
    this->diceShape = new DiceShape(screen);
    break;

  case 4:
    this->boggle = new Boggle(screen);
    break;

  default:
    break;
  }
}

#endif