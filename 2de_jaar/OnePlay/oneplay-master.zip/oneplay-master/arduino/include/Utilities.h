#ifndef PINS_H
#define PINS_H

  /* --- Pin definitions --- */
  #define RIGHT_TOUCH D1
  #define LEFT_TOUCH D2
  #define SELECT_TOUCH D0
  #define LED_PIN RX
  #define BALL_SWITCH A0

  #define TFT_CS D8
  #define TFT_RST D4
  #define TFT_DC D3

  /* --- Contstants definitions --- */
  #define NUMBER_OF_LEDS 4
  #define SPLASH_DURATION 2000

  /* --- AP Variables ---*/
  #ifndef APSSID
    #define APSSID "Jens's SmartDice"
    #define APPSK "123456789"
  #endif

#endif