#ifndef TAP_CONTROLLER_H
#define TAP_CONTROLLER_H

#include <Arduino.h>

class TapController
{
private:
  volatile bool right = LOW;
  volatile bool left = LOW;

  TapController() = default;
  ~TapController() = default;
  TapController(const TapController&) = delete;

  const TapController& operator=(const TapController&) = delete;

public:
  static TapController& getInstance();

  //setters
  void setRightTap(bool s) { this->right = s; };
  void setLeftTap(bool s) { this->left = s; };

  //getters
  bool getRightTap() const { return this->right; };
  bool getLeftTap() const { return this->left; };
};

TapController& TapController::getInstance()
{
  static TapController instance;
  return instance;
}

#endif