#ifndef LED_CONTROLLER_H
#define LED_CONTROLLER_H

#include <FastLED.h>
#include <Utilities.h>

class LedController
{
private:
  CRGB strip[NUMBER_OF_LEDS];
  uint8_t hue = 0;
  int position = beatsin16(5, 0, 192);
  
  LedController();
  ~LedController() = default;
  LedController(const LedController&) = delete;

  const LedController& operator=(const LedController&) = delete;

public:
  static LedController& getInstance();

  void statusConnected();
  void statusDisconnected();
  
  void showRightTap();
  void showLeftTap();
  void showSelectTap();
  void showColor(int color); 

  void waiting();
  void resetToDefaultColor();
};

LedController& LedController::getInstance()
{
	static LedController instance;
	return instance;
}

LedController::LedController() 
{
  FastLED.addLeds<WS2812, RX, GRB>(this->strip, NUMBER_OF_LEDS);
  FastLED.setBrightness(100);
}

void LedController::statusConnected()
{  
  fill_solid(this->strip, NUMBER_OF_LEDS, CRGB::Green);
  FastLED.show();
}

void LedController::statusDisconnected()
{
  fill_solid(this->strip, NUMBER_OF_LEDS, CRGB::Red);
  FastLED.show();
}

void LedController::showRightTap()
{
  this->strip[2] = CRGB::Yellow;
  FastLED.show();
  delay(300);
  this->waiting();
}

void LedController::showLeftTap()
{
  this->strip[0] = CRGB::Yellow;
  FastLED.show();
  delay(300);
  this->waiting();
}

void LedController::showSelectTap()
{
  fill_solid(this->strip, NUMBER_OF_LEDS, CRGB::DarkOrange);
  FastLED.show();
  delay(300);
  this->waiting();
}

void LedController::resetToDefaultColor() 
{
  fill_solid(this->strip, NUMBER_OF_LEDS, CRGB::Blue);
  FastLED.show();
}

// generating the sinwave 
void LedController::waiting() 
{
  fill_solid(this->strip, NUMBER_OF_LEDS, CHSV( this->hue, 255, this->position)); // CHSV (hue, saturation, value);
  FastLED.show();
  EVERY_N_MILLISECONDS(10) { this->hue++; } 
}

// green
// rood, blauw , geel, wit, orange

void LedController::showColor(int color) {
  switch (color)
  {
    case 1:
      fill_solid(this->strip, NUMBER_OF_LEDS, CRGB::Red);
      FastLED.show();
      break;

    case 2:
      fill_solid(this->strip, NUMBER_OF_LEDS, CRGB::Blue);
      FastLED.show();
      break;

    case 3:
      fill_solid(this->strip, NUMBER_OF_LEDS, CRGB::Green);
      FastLED.show();
      break;

    case 4:
      fill_solid(this->strip, NUMBER_OF_LEDS, CRGB::Yellow);
      FastLED.show();
      break;

    case 5:
      fill_solid(this->strip, NUMBER_OF_LEDS, CRGB::Purple);
      FastLED.show();
      break;

    case 6:
      fill_solid(this->strip, NUMBER_OF_LEDS, CRGB::DarkOrange);
      FastLED.show();
      break;
    
    default:
      break;
  }
  
}

#endif