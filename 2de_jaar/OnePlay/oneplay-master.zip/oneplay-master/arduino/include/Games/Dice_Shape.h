#ifndef DICE_SHAPE_H
#define DICE_SHAPE_H

#include "Controllers/LedController.h"

class DiceShape
{
private:
    enum Shape
    {   
        Circle = 1, 
        Square = 2, 
        Oval = 3,
        Diamond = 4,
        Triangle = 5,
        Rectangle = 6
    };
public:
  DiceShape(Adafruit_ST7735& screen);
  ~DiceShape() {}
};

DiceShape::DiceShape(Adafruit_ST7735& screen) 
{
  LedController &ledController = LedController::getInstance();
  srand(time(NULL));
  
  do
  {
    screen.fillScreen(ST77XX_BLACK);
    screen.setRotation(1);
    screen.fillRoundRect(40, 24, 80, 80, 3, ST77XX_WHITE);

    if(analogRead(BALL_SWITCH) == 1024)
    {
      int i = rand() % 6 + 1;
      switch (i)
      {
        case 1: 
          // ONE
          screen.fillCircle(80, 64, 5, ST77XX_GREEN);
          //ledController.showColor(Color::Green);
          break;

        case 2:
          // TWO
          screen.fillRect(45, 60, 40, 40, ST77XX_RED);
          //ledController.showColor(Color::Red);
          break;

        case 3:
          // THREE
          for (int i = 0; i < 20; i++)
          {
            screen.fillCircle(80, 64+i, 5, ST77XX_YELLOW);
          }

          //ledController.showColor(Color::Yellow);
          break; 

        case 4:
          // DIAMOND
          screen.fillTriangle(60, 69, 75, 49, 90, 69, ST77XX_BLUE);
          screen.fillTriangle(60, 69, 75, 89, 90, 69, ST77XX_BLUE);
          //ledController.showColor(Color::Blue);
          break;

        case 5:
          // FIVE
          screen.fillTriangle(60, 69, 75, 49, 90, 69, ST77XX_MAGENTA);
          //ledController.showColor(Color::Purple);
          break;

        case 6:
          // SIX
          screen.fillRect(45, 60, 40, 20, ST77XX_ORANGE);
          //ledController.showColor(Color::Orange);
          break;
          
        default:
          screen.setTextSize(2);
          screen.setTextColor(ST77XX_WHITE);
          screen.setCursor(45, 50);
          screen.println("ERROR");
          break;
      }
      delay(5000);
    }
  } while (digitalRead(SELECT_TOUCH) == LOW);
}

#endif