#ifndef DICE_Letter_H
#define DICE_Letter_H
#include "Controllers/LedController.h"
class DiceLetter
{
private:
    char letter;
public:
  DiceLetter(Adafruit_ST7735& screen);
  ~DiceLetter() {}
};

DiceLetter::DiceLetter(Adafruit_ST7735& screen) 
{
  LedController &ledController = LedController::getInstance();
  srand(time(NULL));
  
  do
  {
    screen.fillScreen(ST77XX_BLACK);
    screen.setRotation(1);
    screen.fillRoundRect(40, 24, 80, 80, 3, ST77XX_RED);
    if(analogRead(BALL_SWITCH) == 1024)
    {
        letter = 'a' + rand() % 26;
        
        screen.setTextSize(5);
        screen.setTextColor(ST77XX_WHITE);
        screen.setCursor(68, 45);
        screen.println(letter);
      
        delay(5000);
    }
  } while (digitalRead(SELECT_TOUCH) == LOW);
}

#endif