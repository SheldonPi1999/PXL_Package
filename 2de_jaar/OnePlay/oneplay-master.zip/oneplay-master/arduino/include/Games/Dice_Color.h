#ifndef DICE_COLOR_H
#define DICE_COLOR_H

#include "Controllers/LedController.h"

class DiceColor
{
private:
    enum Color
    {   
        Red = 1, 
        Blue = 2, 
        Green = 3,
        Yellow = 4,
        Purple = 5,
        Orange = 6
    };
public:
  DiceColor(Adafruit_ST7735& screen);
  ~DiceColor() {}
};

DiceColor::DiceColor(Adafruit_ST7735& screen) 
{
  LedController &ledController = LedController::getInstance();
  srand(time(NULL));
  
  do
  {
    screen.fillScreen(ST77XX_BLACK);
    screen.setRotation(1);
    screen.fillRoundRect(40, 24, 80, 80, 3, ST77XX_WHITE);

    if(analogRead(BALL_SWITCH) > 512)
    {
      int i = rand() % 6 + 1;
      switch (i)
      {
        case 1: 
          // ONE
          screen.fillCircle(80, 64, 5, ST77XX_RED);
          ledController.showColor(Color::Red);
          break;

        case 2:
          // TWO
          screen.fillCircle(80, 64, 5, ST77XX_BLUE);
          ledController.showColor(Color::Blue);
          break;

        case 3:
          // THREE
          screen.fillCircle(80, 64, 5, ST77XX_GREEN);
          ledController.showColor(Color::Green);
          break; 

        case 4:
          // FOUR
          screen.fillCircle(80, 64, 5, ST77XX_YELLOW);
          ledController.showColor(Color::Yellow);
          break;

        case 5:
          // FIVE
          screen.fillCircle(80, 64, 5, ST77XX_MAGENTA);
          ledController.showColor(Color::Purple);
          break;

        case 6:
          // SIX
          screen.fillCircle(80, 64, 5, ST77XX_ORANGE);
          ledController.showColor(Color::Orange);
          break;
          
        default:
          screen.setTextSize(2);
          screen.setTextColor(ST77XX_WHITE);
          screen.setCursor(45, 50);
          screen.println("ERROR");
          break;
      }
      delay(5000);
    }
  } while (digitalRead(SELECT_TOUCH) == LOW);
}

#endif