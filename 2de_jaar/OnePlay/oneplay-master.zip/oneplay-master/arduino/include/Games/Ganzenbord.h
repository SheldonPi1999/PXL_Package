class Ganzenbord
{
private:
  /* data */
public:
  Ganzenbord(/* args */) {}
  ~Ganzenbord() {}
};