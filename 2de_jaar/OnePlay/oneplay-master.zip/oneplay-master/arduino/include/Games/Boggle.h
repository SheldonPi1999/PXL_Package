#ifndef BOGGLE_H
#define BOGGLE_H

#include <Adafruit_ST7735.h>
#include <vector>
#include <time.h>

class Boggle
{
private:
  char l;
  //unsigned seed = time(NULL);
public:
  Boggle(Adafruit_ST7735& screen);
  ~Boggle() {}
};

Boggle::Boggle(Adafruit_ST7735& screen) 
{
  //srand(this->seed);

  byte startValueX = 34;
  byte startValueY = 18;

  srand(time(NULL));

  while(1)
  {      
    screen.fillScreen(ST77XX_BLACK);
    screen.setRotation(1);
    screen.fillRoundRect(25, 9, 110, 110, 10, ST77XX_BLUE);

    for (size_t i = 0; i < 4; i++)
    {
      for (byte j = 0; j < 4; j++) 
      {
        l = 'a' + rand() % 26;

        screen.fillRoundRect((startValueX + (24*j)), (startValueY + (24*i)), 20, 20, 2, ST77XX_WHITE);
        screen.setTextSize(2);
        screen.setCursor(startValueX + 5 + (24*j), startValueY + 3 + (24*i));
        screen.setTextColor(ST77XX_RED);
        screen.println(l);
        
        delay(50);
      }   
    }

    for(size_t i = 0; i < 100; i++ )
    {
      screen.fillRect(30, 125, i+1, 5, ST77XX_WHITE);
      delay(180000/100);
    }
  }
}
#endif