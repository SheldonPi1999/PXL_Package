#ifndef DICE_H
#define DICE

class Dice
{
private:

public:
  Dice(Adafruit_ST7735& screen);
  ~Dice() {}
};

Dice::Dice(Adafruit_ST7735& screen) 
{
  srand(time(NULL));
  
  do
  {
    screen.fillScreen(ST77XX_BLACK);
    screen.setRotation(1);
    screen.fillRoundRect(40, 24, 80, 80, 3, ST77XX_RED);
    if(analogRead(BALL_SWITCH) == 1024)
    {
      switch (rand() % 10 + 1)
      {
        Serial.printf("RANDOM : %d", rand() %10 +1);
        case 1: 
          // ONE
          screen.fillCircle(80, 64, 5, ST77XX_WHITE);
          break;

        case 2:
          // TWO
          screen.fillCircle(60, 44, 5, ST77XX_WHITE);
          screen.fillCircle(100, 84, 5, ST77XX_WHITE);
          break;

        case 3:
          // THREE
          screen.fillCircle(80, 44, 5, ST77XX_WHITE);
          screen.fillCircle(80, 64, 5, ST77XX_WHITE);
          screen.fillCircle(80, 84, 5, ST77XX_WHITE);
          break; 

        case 4:
          // FOUR
          screen.fillCircle(60, 44, 5, ST77XX_WHITE);
          screen.fillCircle(60, 84, 5, ST77XX_WHITE);
          screen.fillCircle(100, 44, 5, ST77XX_WHITE);
          screen.fillCircle(100, 84, 5, ST77XX_WHITE);
          break;

        case 5:
          // FIVE
          screen.fillCircle(80, 64, 5, ST77XX_WHITE);
          screen.fillCircle(60, 44, 5, ST77XX_WHITE);
          screen.fillCircle(60, 84, 5, ST77XX_WHITE);
          screen.fillCircle(100, 44, 5, ST77XX_WHITE);
          screen.fillCircle(100, 84, 5, ST77XX_WHITE);
          break;

        case 6:
          // SIX
          screen.fillCircle(60, 44, 5, ST77XX_WHITE);
          screen.fillCircle(60, 64, 5, ST77XX_WHITE);
          screen.fillCircle(60, 84, 5, ST77XX_WHITE);
          screen.fillCircle(100, 44, 5, ST77XX_WHITE);
          screen.fillCircle(100, 64, 5, ST77XX_WHITE);
          screen.fillCircle(100, 84, 5, ST77XX_WHITE);
          break;
          
        default:
          screen.setTextSize(2);
          screen.setTextColor(ST77XX_WHITE);
          screen.setCursor(45, 50);
          screen.println("ERROR");
          break;
      }
      delay(5000);
    }
  } while (digitalRead(SELECT_TOUCH) == LOW);
}

#endif