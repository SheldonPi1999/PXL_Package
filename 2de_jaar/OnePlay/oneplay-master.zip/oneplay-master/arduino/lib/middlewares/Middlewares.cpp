#include <Middlewares.h>
#include <Arduino.h>

#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <ArduinoJson.h>

//#define __DEBUG__
#define MAX_PLAYERS 2
const size_t capacity = JSON_OBJECT_SIZE(64);

void Middlewares::index(Adafruit_ST7735& screen ) {
  DynamicJsonDocument doc(capacity);

  String data = srv->arg("plain");
  auto error = deserializeJson(doc, data);

  if (error) {
      Serial.print(F("deserializeJson() failed with code "));
      Serial.println(error.c_str());
   
    srv->send(500);
  } else {
    srv->send(200);
  }

  srand(time(NULL));

  Player *player1 = new Player("p1");
  Player *player2 = new Player("p2");

  player1->setKnockOutNumber(doc["p1KnockOutScore"]);
  player2->setKnockOutNumber(doc["p2KnockOutScore"]);

  Serial.println(player1->getKnockOutNumber());
  Serial.println(player1->getKnockOutNumber());

  rollDice(*player1);
  rollDice(*player2);
  
  displayResults(*player1, *player2, screen);
} 

void Middlewares::rollDice(Player& player) 
{  
  for (size_t i = 0; i < 2; i++)
  {
    player.dice[i] = rand() % 6 + 1;
    player.score += player.dice[i];
  }
}

void Middlewares::displayResults(Player &player1, Player &player2 , Adafruit_ST7735& screen)
{
  screen.fillScreen(ST7735_BLACK);

  // LEFT
  screen.setTextColor(ST77XX_WHITE);
  screen.setCursor(32, 10);
  screen.println("P1");
  screen.fillRect(25, 40, 32, 32, ST77XX_RED);
  screen.fillRect(25, 88, 32, 32, ST77XX_RED);
  screen.setCursor(34, 50);
  screen.println(player1.dice[0]);
  screen.setCursor(34, 98);
  screen.println(player1.dice[1]);

  // MIDDLE
  screen.fillRect(80, 0, 2, 128, ST77XX_WHITE);

  // RIGHT
  screen.setTextColor(ST77XX_WHITE);
  screen.setCursor(113, 10);
  screen.println("P2");
  screen.fillRect(107, 40, 32, 32, ST77XX_RED);
  screen.fillRect(107, 88, 32, 32, ST77XX_RED);
  screen.setCursor(119, 50);
  screen.println(player2.dice[0]);
  screen.setCursor(119, 98);
  screen.println(player2.dice[1]);

  screen.setTextColor(ST77XX_YELLOW);
  if((player1.score == player2.getKnockOutNumber()) && player2.score == player1.getKnockOutNumber())
  {
    // DRAW
    screen.fillScreen(ST7735_BLACK);
    screen.setCursor(15, 50);
    screen.println("IT'S A DRAW");
  }
  
  else
  {
    if (player1.score == player2.getKnockOutNumber()) 
    {
      //p2 wins
      screen.fillScreen(ST7735_BLACK);
      screen.setCursor(65, 40);
      screen.println("P2");
      screen.setCursor(37, 60);
      screen.println("HAS WON!");
    }

    if (player2.score == player1.getKnockOutNumber()) 
    {
      // p1 wins
      screen.fillScreen(ST7735_BLACK);
      screen.setCursor(65, 40);
      screen.println("P1");
      screen.setCursor(37, 60);
      screen.println("HAS WON!");
    }
  }
}
