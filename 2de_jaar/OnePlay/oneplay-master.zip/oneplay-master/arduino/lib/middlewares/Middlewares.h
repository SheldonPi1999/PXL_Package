#ifndef MIDDLEWARES_H
#define MIDDLEWARES_H
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <ESP8266WebServer.h>
#include <Player.h>

class Middlewares
{
private:
  ESP8266WebServer *srv;
public:
  Middlewares(ESP8266WebServer &server) : srv(&server) {}
  ~Middlewares() {}
  void index(Adafruit_ST7735& screen);
  void rollDice(Player &player);
  void displayResults(Player &player1, Player &player2 , Adafruit_ST7735& screen);
};

#endif