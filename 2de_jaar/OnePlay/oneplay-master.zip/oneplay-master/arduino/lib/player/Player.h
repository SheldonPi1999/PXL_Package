#include <string>
#include <Adafruit_ST7735.h>

class Player
{
private:
  const char *_name = "";
  short int _knockOutNumber = 0;
  
public:
  Player(const char* name) { this->_name = name; };
  ~Player();

  int dice[2] = {0,0};
  int score = 0;
  void setKnockOutNumber(int number) {  this->_knockOutNumber = number; }
  int getKnockOutNumber() { return this->_knockOutNumber; }
  const char* getPlayerName() { return this->_name; }
};


