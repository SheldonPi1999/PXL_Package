#include <Arduino.h>
/* --- Wifi imports --- */
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>

#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>

#include <Utilities.h>

#include <Middlewares.h>
#include "Controllers/LedController.h"
#include "Controllers/TapController.h"
#include "Menus/GameMenu.h"
#include "Menus/PlatormMenu.h"

bool updateScreen = true;
bool updateWaitingScreen = true;
bool noDeviceConnected = false;

#define __DEBUG__

//objects
ESP8266WebServer server(80);
Adafruit_ST7735 TFTscreen = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_RST);
LedController &ledController = LedController::getInstance();
TapController &tapController = TapController::getInstance();
PlatormMenu &platformMenu = PlatormMenu::getInstance();
GameMenu &gameMenu = GameMenu::getInstance();
Middlewares *middlewares = new Middlewares(server);

/* Wifi event handles */
WiFiEventHandler stationConnectedHandler;
WiFiEventHandler stationDisconnectedHandler;

/* Function declarations */
void onStationConnected(const WiFiEventSoftAPModeStationConnected &evt);
void onStationDisconnected(const WiFiEventSoftAPModeStationDisconnected &evt);
void splashScreen();
void displayWaitingMessage();

/* Interrupt Handlers */
void ICACHE_RAM_ATTR indicateRightTap() { tapController.setRightTap(true); };
void ICACHE_RAM_ATTR indicateLeftTap() { tapController.setLeftTap(true); };

void setup() 
{
  //Local variables
  bool hasChosenPlatform = false;
  bool updateScreen = true;

  #ifdef __DEBUG__
    delay(1000);
    Serial.begin(115200);
    Serial.printf("%s\n", "Configuring access point...");
  #endif

  // Inputs
  pinMode(RIGHT_TOUCH, INPUT_PULLUP);
  pinMode(LEFT_TOUCH, INPUT_PULLUP);
  pinMode(SELECT_TOUCH, INPUT_PULLUP);
  pinMode(BALL_SWITCH, INPUT);

  //Outputs
  pinMode(LED_PIN, OUTPUT);

  //Attach interupts
  attachInterrupt(digitalPinToInterrupt(RIGHT_TOUCH), indicateRightTap, RISING);
  attachInterrupt(digitalPinToInterrupt(LEFT_TOUCH), indicateLeftTap, RISING);

  TFTscreen.initR(INITR_BLACKTAB);
  TFTscreen.fillScreen(ST77XX_WHITE);

  splashScreen();

  delay(SPLASH_DURATION);

  WiFi.softAPdisconnect(true);

  do
  {
    ledController.waiting();
    if (updateScreen == true)
    {
      platformMenu.displayMenu(TFTscreen, platformMenu.counter);
      updateScreen = false;
    }

    if (tapController.getRightTap() == true)
    {
      ledController.showRightTap();
      tapController.setRightTap(false);

      if (platformMenu.counter == 1) continue;
      else platformMenu.displayMenu(TFTscreen, ++platformMenu.counter);
    }

    else if (tapController.getLeftTap() == true) 
    {
      ledController.showLeftTap();
      tapController.setLeftTap(false);

      if (platformMenu.counter == 0) continue;
      else platformMenu.displayMenu(TFTscreen, --platformMenu.counter);
    }

    else if (digitalRead(SELECT_TOUCH) == HIGH)
    {
      ledController.showSelectTap();

      if (platformMenu.counter == 0)
      {
        //enable wifi
        WiFi.softAP(APSSID, APPSK, true, false, true);
        stationConnectedHandler = WiFi.onSoftAPModeStationConnected(&onStationConnected);
        stationDisconnectedHandler = WiFi.onSoftAPModeStationDisconnected(&onStationDisconnected);

        #ifdef __DEBUG__
          Serial.print("IP address: ");
          Serial.println(WiFi.softAPIP());
          Serial.printf("MAC address = %s\n", WiFi.softAPmacAddress().c_str());
        #endif

        server.begin();
        server.on("/", HTTP_ANY, []() { middlewares->index(TFTscreen); });

        #ifdef __DEBUG__
          Serial.printf("%s\n", "HTTP server started");
        #endif

        if (WiFi.softAPgetStationNum() == 0) ledController.statusDisconnected();
      }

      else 
      {
        WiFi.softAPdisconnect(true);
      }
      hasChosenPlatform = true;
    }
    yield(); //Clear the watchdog timer
  } while (hasChosenPlatform != true);
}

void loop() 
{
  if (platformMenu.counter == 0) 
  {
    server.handleClient();
    if (updateWaitingScreen == true)
    {
      displayWaitingMessage();
      updateWaitingScreen = false;
    } 
  }

  else
  {
    if (updateScreen == true)
    {
      gameMenu.displayMenu(TFTscreen, gameMenu.counter);
      updateScreen = false;
    }

    if (digitalRead(SELECT_TOUCH) == HIGH)
    {
      ledController.showSelectTap();
      gameMenu.playGame(TFTscreen,gameMenu.counter);
    }

    else if (tapController.getRightTap() == true) 
    {
      ledController.showRightTap();
      tapController.setRightTap(false);
      if (gameMenu.counter == 4) gameMenu.counter = 4;
      else gameMenu.displayMenu(TFTscreen, ++gameMenu.counter);
    }

    else if (tapController.getLeftTap() == true) 
    {
      ledController.showLeftTap();
      tapController.setLeftTap(false);
      if (gameMenu.counter == 0) gameMenu.counter = 0;
      else gameMenu.displayMenu(TFTscreen, --gameMenu.counter);
    }
  }
}


/**
  * @brief : Registers a connected device 
  * @return : void
**/
void onStationConnected(const WiFiEventSoftAPModeStationConnected &evt)
{
#ifdef __DEBUG__
  Serial.print("Device connected");
#endif
  noDeviceConnected = true;
  ledController.statusConnected();
}

/**
  * @brief : Registers a disconnected device 
  * @return : void
**/
void onStationDisconnected(const WiFiEventSoftAPModeStationDisconnected &evt)
{
#ifdef __DEBUG__
  Serial.print("Client disconnected");
#endif

  ledController.statusDisconnected();
}

/**
  * @brief : Shows splashscreen
  * @return : void
**/
void splashScreen()
{
  TFTscreen.setRotation(1);

  TFTscreen.setTextColor(ST77XX_BLUE);
  TFTscreen.setTextSize(3);
  TFTscreen.setCursor(15, 40);
  TFTscreen.print("One");

  TFTscreen.setTextColor(ST77XX_BLACK);
  TFTscreen.setTextSize(4);
  TFTscreen.print("P");

  TFTscreen.setTextColor(ST77XX_BLUE);
  TFTscreen.setTextSize(3);
  TFTscreen.println("lay");

  TFTscreen.setTextColor(ST77XX_BLACK);
  TFTscreen.setTextSize(1);
  TFTscreen.setCursor(20, 70);
  TFTscreen.print("Be ");

  TFTscreen.setTextColor(ST77XX_RED);
  TFTscreen.print("smart ");

  TFTscreen.setTextColor(ST77XX_BLACK);
  TFTscreen.print("Play ");

  TFTscreen.setTextColor(ST77XX_RED);
  TFTscreen.println("smart");

  for (int x = 0; x < 5; x++)
  {
    for (int y = 0; y < 5; y++)
    {
      TFTscreen.fillCircle(78, 48, 3, ST77XX_RED);
    }
  }
}

void displayWaitingMessage()
{
  TFTscreen.fillScreen(ST77XX_BLACK);
  TFTscreen.setRotation(1);

  TFTscreen.fillCircle(80, 64, 60, ST77XX_BLUE);
  TFTscreen.fillCircle(80, 64, 55, ST77XX_BLACK);

  /*
    BP BlueCircle  = 80
    BP WhiteCircle = 22
    Distance       = 80-22 = 58
    
    (80 - i)² + (64-yw)² = 58²
    (64-yw)² = 58² - (80-i)²
    64 - root(58² - (80-i)²) = yw

  */
  TFTscreen.setTextColor(ST77XX_WHITE);
  TFTscreen.setTextSize(2);
  TFTscreen.setCursor(39, 57);
  TFTscreen.print("WAITING");

  TFTscreen.fillRect(35, 75, 90, 3, ST77XX_RED);

  int BallLength = 20;

  while (noDeviceConnected == false)
  {
    for (int i = 22; i <= (138 + BallLength); i++)
    {
      if (i < 138)
      {
        TFTscreen.fillCircle(i, (static_cast<int>(64 - sqrt(pow(58, 2) - pow((80 - i), 2)))), 2, ST77XX_WHITE);
      }
      if (i >= (22 + BallLength))
      {
        TFTscreen.fillCircle(i - BallLength, (static_cast<int>(64 - sqrt(pow(58, 2) - pow((80 - (i - BallLength)), 2)))), 2, ST77XX_BLUE);
      }
      delay(20);
    }

    for (int i = 138; i >= 22 - BallLength; i--)
    {
      if (i > 22)
      {
        TFTscreen.fillCircle(i, 128 - (static_cast<int>(64 - sqrt(pow(58, 2) - pow((80 - i), 2)))), 2, ST77XX_WHITE);
      }
      if (i <= (138 - BallLength))
      {
        TFTscreen.fillCircle(i + BallLength, 128 - (static_cast<int>(64 - sqrt(pow(58, 2) - pow((80 - (i + BallLength)), 2)))), 2, ST77XX_BLUE);
      }
      delay(20);
    }
  }
}


