#include <Middlewares.h>
#include <Arduino.h>
#include <ArduinoJson.h>
#include <vector>

{
  "p1KnockOutScore":"50",
  "p2KockOutScore": "20"
}

//#define __DEBUG__

// https://arduinojson.org/v6/assistant/
#define AMOUNT_OF_PLAYERS 4
const size_t capacity = JSON_ARRAY_SIZE(4) + JSON_OBJECT_SIZE(1) + 30;

void Middlewares::index() {
  String data = srv->arg("plain");

  DynamicJsonDocument doc(capacity);
  std::vector<String > v;

  auto error = deserializeJson(doc, data);

  if (error) {
    #ifdef __DEBUG__
      Serial.print(F("deserializeJson() failed with code "));
      Serial.println(error.c_str());
    #endif

    srv->send(500);
    return;
  } else {
    srv->send(200);
  }

  JsonArray names = doc["names"];
  for (size_t i = 0; i < AMOUNT_OF_PLAYERS; i++) { v.push_back(names[i]); }

  #ifdef __DEBUG__
    int it = 1;
    for (auto const& i: v) {
      Serial.printf("Playername %d " , it);
      it++;
      Serial.println(i);
    }
  #endif

} 