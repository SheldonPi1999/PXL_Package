https://www.digitalocean.com/community/tutorials/how-to-install-wordpress-with-lamp-on-ubuntu-18-04

## Add DNS to registrar

- [ ] n1.digitalocean.com
- [ ] n2.digitalocean.com
- [ ] n3.digitalocean.com

## Assign domain to droplet

- [ ] Add A-records :
  - [ ] A-record : oneplay.digital **_directs_** to 64.225.69.229
  - [ ] A-record : configure.oneplay.digital **_directs to_** 64.225.69.229
- [ ] Create CNAME records :
  - [ ] CNAME : www.configure.oneplay.digital **_is an alias of_**configure.oneplay.digital
  - [ ] CNAME : www.oneplay.digital **_is an alias_** of oneplay.digital

| Type  |           Hostname            |                  Value                   | TTL (seconds) |
| ----- | :---------------------------: | :--------------------------------------: | :-----------: |
| NS    |        oneplay.digital        |     directs to ns1.digitalocean.com      |     1800      |
| NS    |        oneplay.digital        |     directs to ns2.digitalocean.com      |     1800      |
| NS    |        oneplay.digital        |     directs to ns3.digitalocean.com      |     1800      |
| A     |        oneplay.digital        |          directs to IP address           |     3600      |
| A     |   configure.oneplay.digital   |          directs to IP address           |     3600      |
| CNAME | www.configure.oneplay.digital | is an alias of configure.oneplay.digital |     43200     |
| CNAME |      www.oneplay.digital      |      is an alias of oneplay.digital      |     43200     |

## Make SSL - certificate

- [ ] run cert-bot command
- [ ] Redirect all traffic == true

## Configure subdomain

- [ ] Cd to `/etc/apache2/sites-enabled/`
  - [ ] Change the 2 files `000-default.conf` and 000-default-le-ssl.conf`
  - [ ] **_WAIT UNTIL GENERATION OF SSL CERTIFICATE_**
- [ ] Create folder in /var/www
  - [ ] subdomain
  - [ ] create basic html file
  - [ ] change folder permissions
    - `chmod -R 755 subdomain`
  - [ ] Restart apache2
    - `service apache2 restart`
  - [ ] Create SSL certificate for the domain
    - `certbot --apache -d configure.oneplay.digital -d www.configure.oneplay.digital`
  - [ ] Restart apache2
    - `service apache2 restart`
  - [ ] sudo certbot --apache -d oneplay.digital -d www.oneplay.digital
  - [ ] sudo certbot renew --dry-run

### Accounts created :

- JetPack
- configured Oauth token : developer.google.com
- Elementor : https://my.elementor.com
- Mailchimp : https://login.mailchimp.com/
- Name : http://www.name.com
- Server
  - Renewal email : oneplay.digital@gmail.com
- Google developer account (Oauth)

## Handy commands

```sql
  ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password here';

  -- Authenticate with root
  mysql -u root -p

  -- Create new user
  CREATE USER 'user'@'localhost' IDENTIFIED BY 'password here';

  -- Create permittions
  GRANT ALL PRIVILEGES ON *.* TO 'user'@'localhost' WITH GRANT OPTION;

  -- Create wordpress db
  CREATE DATABASE wordpress DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
```
