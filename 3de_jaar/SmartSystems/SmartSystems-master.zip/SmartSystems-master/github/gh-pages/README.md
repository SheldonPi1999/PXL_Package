# SmartSystems
Example dump for Smart Systems by Vincent Claes
