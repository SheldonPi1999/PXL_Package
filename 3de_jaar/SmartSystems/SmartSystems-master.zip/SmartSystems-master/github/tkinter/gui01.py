from tkinter import *

root = Tk()
root.geometry('300x300')
root.title("GUI Example")
root.mainloop()