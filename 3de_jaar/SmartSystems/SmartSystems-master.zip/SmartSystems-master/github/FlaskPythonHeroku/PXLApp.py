from flask import Flask, url_for, request, json, Response, jsonify
from functools import wraps

app = Flask(__name__)

# test with curl -i https://xxxxx.herokuapps.com/hi
@app.route('/hi', methods = ['GET'])
def api_hi():
    data = {
        'hello': 'hiworld',
        'number': 456
    }
    js = json.dumps(data)
    
    resp = Response(js, status=200, mimetype='application/json')
    resp.headers['Link']= 'http://www.cteq.eu'
    return resp

    
@app.route('/predict', methods = ['POST'])
def predict(water, cement, ash, plastic):
    model_pkl = pickle.load(open('./CementStrength.pkl','rb'))
    prediction = model_pkl.predict(pd.DataFrame([[water, cement, 0, 200, 6.4, 1000, 754, 20]]))
    return jsonify(prediction)



if __name__ == '__main__':
    app.run()
   