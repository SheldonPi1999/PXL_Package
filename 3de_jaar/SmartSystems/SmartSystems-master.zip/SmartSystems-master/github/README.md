# SmartSystems
by Vincent Claes

- Example 3: R Shiny Application Example [ R Languages]
- Flask Example: Example for writing Flask Applications [Python / Flask]
- Flask Example HTML: Example for implementing redering HTML sites [Python / Flask]
- Flask Python Heroku: Example howto host a Flask Application on Heroku [Python / Flask / Heroku / ProcFile / requirements.txt]
- Flask Python Heroku DB: Example howto setup a Flask-PostgreSQL database On Heroku [Python/ Flask / Heroku / PostgreSQL]
- Flask Python Heroku ML Host: Example howto host a Machine Learning Model on Heroku with a HTML User Interface [Python / Flask / Heroku / HTML / SKLEARN / Machine Learning ]
- Python Open CV: Open CV Stitching Application in Python [Python / OpenCV / Vision]
- tkinter : Python GUI Example [Python / Tkinter / UI]

More information see slideshare account: https://www.slideshare.net/fpgabe/
