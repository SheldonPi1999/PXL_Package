#!/bin/sh
APP_NAME="myappzezadsez"

# pip freeze > requirements.txt

echo "gunicorn\nFlask" > requirements.txt

echo "web:gunicorn $APP_NAME:app" > Procfile

touch "$APP_NAME.py"

git init

# heroku login
heroku create $APP_NAME

heroku addons:create heroku-postgresql:hobby-dev -a $APP_NAME

heroku git:remote -a $APP_NAME

git add .

git commit -am "Init"

git push heroku master



