// --------------------------------------------------------------- //
//                                                                 //
// ® Copyright Toetenel Kasper en Vanhulst Jens                    //
// TITLE : Arduino Led Matrix driver                               //
// Authors :  Toetenel Kasper & Vanhulst Jens                      //
// Git repo : https://github.com/JensVanhulst/ArduinoProjectPXL    //
//                                                                 //
// --------------------------------------------------------------- //
#include <Arduino.h>
#include <MatrixEncoder.h>

/*===================================
=             PIN MAPPING           =
===================================*/

/* ----- LED MATRIX ----- */
#define SH_PIN 8 // SHIFT
#define ST_PIN 7 // LATCH
#define DS_PIN 6 // SERIAL

/* ----- Flappy ----- */
#define BTN_UP_PIN 10       // UP
#define BTN_DOWN_PIN 11     // DOWN
#define BTN_OBSTACLE_PIN 12 // DOWN

int i = 4; // Startflappy
int j = 0;
bool BTN_UP = false;
bool BTN_DOWN = false;
bool BTN_OBSTACLE = false;

/* ----- Init ----- */
MatrixEncoder matrixEncoder(SH_PIN, ST_PIN, DS_PIN);

void gameOver();
void flappyBird();

byte flappykut[8] = {
    0b00000000,
    0b00000000,
    0b00000000,
    0b00000000,
    0b10000000,
    0b00000000,
    0b00000000,
    0b00000000};

byte flappyObstacle[8] = {
    0b00000001,
    0b00000001,
    0b00000001,
    0b00000001,
    0b00000000,
    0b00000001,
    0b00000001,
    0b00000001};

void setup()
{
  Serial.begin(9600);
  pinMode(SH_PIN, OUTPUT);
  pinMode(ST_PIN, OUTPUT);
  pinMode(DS_PIN, OUTPUT);

  pinMode(BTN_UP_PIN, INPUT);
  pinMode(BTN_DOWN_PIN, INPUT);
  pinMode(BTN_OBSTACLE_PIN, INPUT);
}

void loop()
{
  gameOver();
  // flappyBird();
}

void flappyBird()
{
  matrixEncoder.clear();
  matrixEncoder.print(flappykut);
  matrixEncoder.print(flappyObstacle);

  BTN_UP = digitalRead(BTN_UP_PIN);
  BTN_DOWN = digitalRead(BTN_DOWN_PIN);
  BTN_OBSTACLE = digitalRead(BTN_OBSTACLE_PIN);

  Serial.print(i);

  if (i > 0 && BTN_UP)
  {
    i--;
    flappykut[i] = flappykut[i + 1];
    flappykut[i + 1] = 0;
    delay(500);
  }

  else if (i < 7 && BTN_DOWN)
  {
    i++;
    flappykut[i] = flappykut[i - 1];
    flappykut[i - 1] = 0;
    delay(500);
  }

  else if (BTN_OBSTACLE)
  {
    if (flappyObstacle[0] == 0b10000000)
    {
      for (j = 0; j < 8; j++)
      {
        flappyObstacle[j] = flappyObstacle[j] >> 7;
      }
    }

    else
    {
      for (j = 0; j < 8; j++)
      {
        flappyObstacle[j] = flappyObstacle[j] << 1;
      }
    }

    delay(500);
  }
}

void gameOver()
{
  byte letter_G[8] = {
      0b00000000,
      0b00111110,
      0b01000000,
      0b01011100,
      0b01000010,
      0b01000010,
      0b01111100,
      0b00000000};

  byte letter_A[8] = {
      0b00000000,
      0b00011000,
      0b00100100,
      0b01111110,
      0b01000010,
      0b01000010,
      0b01000010,
      0b00000000};

  byte letter_M[8] = {
      0b00000000,
      0b00000000,
      0b01111000,
      0b01010100,
      0b01010100,
      0b01010100,
      0b01010100,
      0b00000000};

  byte letter_E[8] = {
      0b00000000,
      0b01111110,
      0b01000000,
      0b01111110,
      0b01000000,
      0b01000000,
      0b01111110,
      0b00000000};

  byte letter_O[8] = {
      0b00000000,
      0b00111100,
      0b01000010,
      0b01000010,
      0b01000010,
      0b01000010,
      0b00111100,
      0b00000000};

  byte letter_V[8] = {
      0b00000000,
      0b01000010,
      0b01000010,
      0b01000010,
      0b00100100,
      0b00111100,
      0b00011000,
      0b00000000};

  byte letter_R[8] = {
      0b00000000,
      0b01111110,
      0b01000010,
      0b01111110,
      0b01001000,
      0b01000100,
      0b01000010,
      0b00000000};

  for (int gameOverLoop = 0; gameOverLoop < 500; gameOverLoop++)
  {
    matrixEncoder.print(letter_G);
  }
  for (int gameOverLoop = 0; gameOverLoop < 500; gameOverLoop++)
  {
    matrixEncoder.print(letter_A);
  }
  for (int gameOverLoop = 0; gameOverLoop < 500; gameOverLoop++)
  {
    matrixEncoder.print(letter_M);
  }
  for (int gameOverLoop = 0; gameOverLoop < 500; gameOverLoop++)
  {
    matrixEncoder.print(letter_E);
  }  
  for (int gameOverLoop = 0; gameOverLoop < 500; gameOverLoop++)
  {
    matrixEncoder.print(letter_O);
  }
  for (int gameOverLoop = 0; gameOverLoop < 500; gameOverLoop++)
  {
    matrixEncoder.print(letter_V);
  }
  for (int gameOverLoop = 0; gameOverLoop < 500; gameOverLoop++)
  {
    matrixEncoder.print(letter_E);
  }
  for (int gameOverLoop = 0; gameOverLoop < 500; gameOverLoop++)
  {
    matrixEncoder.print(letter_R);
  }
}