/****
 * Enter your AllThingsTalk device credentials below
 */
#ifndef KEYS_h
#define KEYS_h
const char* DEVICE_ID = "gSR8IhxpXnWZOMb9z2M4XBN1";
const char* DEVICE_TOKEN = "maker:4JdliozpfT96m0lqFybasVTchFoYoSqbKEzFlPc0";
const char* APN = "starter.att.iot";
#endif
