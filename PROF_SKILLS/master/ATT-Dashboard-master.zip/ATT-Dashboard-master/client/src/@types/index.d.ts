declare module 'vue-grid-layout';
declare module 'v-offline';
declare module 'vue-page-transition';
