<template>
    <div>
        <embed src="https://maker.allthingstalk.com/" style="width:100%; height:800px;" />
    </div>
</template>
